//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <math.h>



#include "MainFrame.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "visualizer"
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
   dcx_V=GetDC(Frame_V->Panel_V->Handle);
   cou_V=0;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Frame_V1Button_V01Click(TObject *Sender)
{

   obj_V= new Toge();
   obj_V->scinit(dcx_V);
   obj_V->setSize(400,400);
   obj_V->sfomat();
   Frame_V->Timer_V->Enabled=true;

}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Frame_V1Timer_VTimer(TObject *Sender)
{
     double data[20];
     float cou_Vx;
     int i,va,front_eff,back_eff,mid_eff,rr;

     va=StrToInt(MainForm->Edit1->Text);
     cou_Vx=StrToFloat(MainForm->Edit5->Text);

     front_eff=StrToInt(MainForm->Edit2->Text);
     back_eff=StrToInt(MainForm->Edit3->Text);
     mid_eff=StrToInt(MainForm->Edit4->Text);
     rr=StrToInt(MainForm->Edit6->Text);

     cou_V=cou_V+1;
     if(cou_V>359){ cou_V=0; }
     for(i=0;i<14;i++){
       data[i]=100*sin(3.141592*(cou_V+24*i)/180);
       if(MainForm->CheckBox1->Checked==true){ data[i]=0; }
     }


     obj_V->TogeModel(va,front_eff,back_eff,mid_eff,cou_V,cou_Vx,14,data,60,rr);
     Memo1->Lines->Add(cou_V);
     obj_V->draw();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Frame_VButton_V02Click(TObject *Sender)
{
   Frame_V->Timer_V->Enabled=false;

}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Button1Click(TObject *Sender)
{
   double a;

   a=2.5*2.5+1.5*1.5;
   a=sqrt(a);

   Memo1->Lines->Add(acos(2.5/a)*180/3.141592);

}
//---------------------------------------------------------------------------

