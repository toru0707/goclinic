//---------------------------------------------------------------------------
//OpenGL�ɂ��`��
//00801doi
#ifndef TogeH
#define TogeH
#include <windows.h>

//#include <gl/glut.h>

//---------------------------------------------------------------------------
class Toge
{
private:
    HGLRC rx;
    HDC dx;
    int ch_flg[20];
    int width,height;

public:
    enum {side,top,bird} viewtype;
    Toge();
    ~Toge();
    char outer_product(double vx1_in,double vy1_in,double vz1_in,
                       double vx2_in,double vy2_in,double vz2_in,
                       double *vx_out,double *vy_out,double *vz_out
                       );
    //���O��
    void Facet(double x0,double y0,double z0,
                       double x1,double y1,double z1,
                       double x2,double y2,double z2);

    //���|���S�����f�����O�D�@����
    void scinit(void *win_hd);
    void sfomat();
    void draw();
    void d_end();
    void setSize(int _width, int _height){width=_width;height=_height;};

    void TogeModel(int t_var,int t_fro,int t_bak,int t_mid,int vt,float vtx,int n,double dat[],int shl,int rr);
    void TogeObj04(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_fro,int t_bak,int t_mid,int rr);
    void TogeObj04_1(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_1_t4(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_1_t5(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_1_t6(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_1_t7(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_1_t8(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_1_t9(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_1_t10(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back01(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back02(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_01(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_02(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_03(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_04(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_05(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_06(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_07(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_08(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_09(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_back03_10(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front01(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front01_01(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front01_02(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front02(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front03(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front04(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front05(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front06(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front07(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front08_01(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front08_02(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front08_03(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front08_04(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front09(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front10(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front11(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front12(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front13(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front_yen(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front_sho(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front_dai(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front_dol(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front_hand01(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front_hand02(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_front_hand02_h(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_mid01(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_mid02(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_mid03(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_mid04(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_2(double ir,double ig,double ib,double ia);
    void TogeObj04_3(double ir,double ig,double ib,double ia);
    void TogeObj04_4(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp,int hou);
    void TogeObj04_5(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_5_1(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_6(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_7(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_8(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_9(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_10(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_11(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_12(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_13(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_14(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_15(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_16(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_17(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_18(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp,int rr);
    void TogeObj04_19(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_20(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_21(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_22(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_23(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp,int hou);
    void TogeObj04_24(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_25(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_26(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_27(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_28(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);
    void TogeObj04_29(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp);

    void TogeObj04_bg(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_amp,double rr,double gg,double bb);
    void Frame(double x0,double x1,double y0,double y1,double z0,double z1);
    void Box(double x0,double x1,double y0,double y1,double z0,double z1);
    void ho(double x0,double y0,double z0);
    void nobi(double x0,double y0,double z0);
    void mi(double x0,double y0,double z0);
    void Kyu(double r,double xy,double yz);
    void Ensui(double r1,double r2,double h);
    void sq_plate(double x1,double x2,double y1,double y2,double z);
    void sq_plate2(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4,double z);
    void tri_plate(double x1,double y1,double x2,double y2,double x3,double y3,double z);
    void tri_plate2(double xa,double ya,double e1,double e2,double alh,double z);
    void penta_plate(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4,double x5,double y5,double z);
    void drop_plate(double xa,double ya,double e1,double e2,double alh,double z);

    void color_set(double r,double g,double b,double alpha);


    double td[20];


};
//---------------------------------------------------------------------------
#endif

