//---------------------------------------------------------------------------


#ifndef visualizerH
#define visualizerH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFrame_V : public TFrame
{
__published:	// IDE �Ǘ��̃R���|�[�l���g
        TPanel *Panel_V;
        TButton *Button_V01;
        TTimer *Timer_V;
        TButton *Button_V02;
private:	// ���[�U�[�錾
public:		// ���[�U�[�錾
        __fastcall TFrame_V(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrame_V *Frame_V;
//---------------------------------------------------------------------------
#endif
