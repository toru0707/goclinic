//---------------------------------------------------------------------------
//OpenGL���g�����{�u�̕\��
//------------------------------------------------------
#include <windows.h>
#include "Toge.h"
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>
#include <math.h>
//---------------------------------------------------------------------------
Toge::Toge()
{
  int i;

  viewtype=bird;

  for(i=0;i<20;i++){
    ch_flg[i]=1;
  }
}
//---------------------------------------------------------------------------
Toge::~Toge()
{
  wglDeleteContext(rx);
}
//---------------------------------------------------------------------------
void Toge::scinit(void *win_hd)
{
  dx=(HDC)win_hd;
  PIXELFORMATDESCRIPTOR pfd=
    {
    sizeof(PIXELFORMATDESCRIPTOR),
    1,
    PFD_DRAW_TO_WINDOW |
        PFD_SUPPORT_OPENGL|
            PFD_DOUBLEBUFFER,
    PFD_TYPE_RGBA,
    24,
    0,0,0,0,0,0,
    0,0,0,0,0,0,0,

    32,
    0,0,
    PFD_MAIN_PLANE,
    0,
    0,0,0
    };

  int pixelFormat=ChoosePixelFormat(dx,&pfd);
  if(SetPixelFormat(dx,pixelFormat,&pfd)==false);

}
//---------------------------------------------------------------------------
void Toge::sfomat()
{
  rx=wglCreateContext(dx);
  if(wglMakeCurrent(dx,rx)==0){}
}
//---------------------------------------------------------------------------
void Toge::draw()
{
  glFlush();
  if(SwapBuffers(dx)==false){ }

}

//---------------------------------------------------------------------------
void Toge::d_end()
{
  if(wglMakeCurrent(dx,NULL)==0){  }
  wglDeleteContext(rx); //�������̉��

}
//---------------------------------------------------------------------------
void Toge::TogeModel(int t_var,int t_fro,int t_bak,int t_mid,int vt,float vtx,int n,double dat[],int shl,int rr){
  //���f�����O

  int cutr;
  int i;

  //�f�[�^����
  for(i=0;i<n;i++){
    if(dat[i]<-100.0){ dat[i]=-100.0; }
    if(dat[i]>100.0){ dat[i]=100.0; }

    //�f�[�^�𐳕��ɐU�蕪����B
    if(fabs(dat[i])<1.0){ ch_flg[i]=ch_flg[i]*(-1); }

  }

  vt=(int)((float)vt*vtx) % 360;

  //�`��̏����ݒ�
  glViewport(0, 0, width, height);   //����͈�
  glClearColor(0.0, 0.0, 0.0, 0.0); //�o�b�N�O���E���h�̐F
  glMatrixMode(GL_PROJECTION);      //
  glLoadIdentity();
  gluPerspective(45.0, (float)width/(float)height, 2.0, 200.0);
  glEnable(GL_DEPTH_TEST);

  // �Ɩ��̐ݒ�
  static GLfloat position[] = {0.0f, -20.0f, -30.0f, 1.0f};
  static GLfloat ambient [] = {1.0f, 1.0f, 1.0f, 1.0f};
  static GLfloat diffuse [] = {1.0f, 1.0f, 1.0f, 1.0f};
  static GLfloat specular[] = {0.0f, 0.0f, 0.0f, 0.0f};
  glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
  glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
  glLightfv(GL_LIGHT0, GL_POSITION, position);

  glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);

  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // �}�e���A���̐ݒ�

  GLfloat ambient1  [] = {0.1f, 0.1f, 0.1f, 1.0f};
  GLfloat diffuse1  [] = {1.0f, 0.0f, 0.0f, 1.0f};
  GLfloat specular1 [] = {1.0f, 1.0f, 1.0f, 1.0f};
  GLfloat shininess1[] = {0.0f};
  glMaterialfv(GL_FRONT, GL_AMBIENT, ambient1);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse1);
  glMaterialfv(GL_FRONT, GL_SPECULAR, specular1);
  glMaterialfv(GL_FRONT, GL_SHININESS, shininess1);


  // ���_�̐ݒ�
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  cutr=20;

  //TogeObj04(�{�u��)
  gluLookAt( 0.0f,  0.0f,-30.0f,0.0f,  0.0f, 0.0f,0.0f, -1.0f, 0.0f);
  TogeObj04(vt,n,dat,cutr,shl,t_var,t_fro,t_bak,t_mid,rr);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04(int vt,int n,double dat[],int cutr,int shl,int t_var,int t_fro,int t_bak,int t_mid,int rrd){
  //(�{�u��)
  double hi[20],r,r1,r2,h_max;
  int sita;
  double t_amp;
  double rr,gg,bb;
  int i,j;


  sita=vt;

  h_max=1.0;  //�ő�̍���

  for(i=0;i<20;i++){
    hi[i]=0.0;
  }

  j=1;
  t_amp=0.0;
  for(i=0;i<n;i++){
    hi[i]=h_max*dat[i]/100.0;
    t_amp=t_amp+fabs(dat[i]);
    if(fabs(dat[i])>5){ j++; }
  }
  t_amp=t_amp/j;


  glEnable(GL_BLEND);
  glBlendFunc(GL_ONE, GL_ZERO);

  // �����łȂ��I�u�W�F�N�g��`���ꏊ

  //�G���[���p�̃I�u�W�F�N�g
  glPushMatrix();
    GLUquadric* qe=gluNewQuadric();
    glRotatef(90,1,0,0);
    try{
      gluCylinder(qe, 0.01,0.01,0.01, cutr, 30);
    }
    catch(...){}
    gluDeleteQuadric(qe);
  glPopMatrix();

  switch(t_var){

    case 0:
            break;
    case 1:
            TogeObj04_1(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 2:
            TogeObj04_8(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 3:
            TogeObj04_8(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 4:
            TogeObj04_9(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 5:
            TogeObj04_6(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 6:
            TogeObj04_6(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 7:
            TogeObj04_4(sita,n,hi,cutr,shl,t_var,t_amp,1);
            break;
    case 8:
            TogeObj04_4(sita,n,hi,cutr,shl,t_var,t_amp,2);
            break;
    case 9:
            TogeObj04_10(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 10:
            TogeObj04_1_t4(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 11:
            TogeObj04_1_t5(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 12:
            TogeObj04_1_t6(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 13:
            TogeObj04_1_t7(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 14:
            TogeObj04_1_t8(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 15:
            TogeObj04_1_t9(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 16:
            TogeObj04_11(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 17:
            TogeObj04_1_t10(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 18:
            TogeObj04_15(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 19:
            TogeObj04_16(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 20:
            TogeObj04_17(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 21:
            TogeObj04_18(sita,n,hi,cutr,shl,t_var,t_amp,rrd);
            break;
    case 22:
            TogeObj04_19(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 23:
            TogeObj04_20(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 24:
            TogeObj04_21(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 25:
            TogeObj04_14(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 26:
            TogeObj04_22(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 27:
            TogeObj04_23(sita,n,hi,cutr,shl,t_var,t_amp,2);
            break;
    case 28:
            TogeObj04_24(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 29:
            TogeObj04_25(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 30:
            TogeObj04_26(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 31:
            TogeObj04_27(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 32:
            TogeObj04_28(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
    case 33:
            TogeObj04_29(sita,n,hi,cutr,shl,t_var,t_amp);
            break;

/*
    case 34:
            TogeObj04_13(sita,n,hi,cutr,shl,t_var,t_amp);
            //���ꗎ����i�g��Ȃ��H�j
            break;
*/
    default:
            TogeObj04_1(sita,n,hi,cutr,shl,t_var,t_amp);
            break;
  }

  if(t_fro==1){ TogeObj04_front01(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==2){ TogeObj04_front01_01(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==3){ TogeObj04_front01_02(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==4){ TogeObj04_front02(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==5){ TogeObj04_front03(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==6){ TogeObj04_front04(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==7){ TogeObj04_front05(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==8){ TogeObj04_front06(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==9){ TogeObj04_front07(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==10){ TogeObj04_front08_01(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==11){ TogeObj04_front08_02(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==12){ TogeObj04_front08_03(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==13){ TogeObj04_front08_04(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==14){ TogeObj04_front_hand01(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==15){ TogeObj04_front_hand02(sita,n,hi,cutr,shl,t_var,t_amp);
                 TogeObj04_front_hand02_h(sita,n,hi,cutr,shl,t_var,t_amp);    
  }
  if(t_fro==16){ TogeObj04_front09(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==17){ TogeObj04_front_yen(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==18){ TogeObj04_front10(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==19){ TogeObj04_front11(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==20){ TogeObj04_front12(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==21){ TogeObj04_front13(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==22){ TogeObj04_front_sho(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==23){ TogeObj04_front_dai(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_fro==24){ TogeObj04_front_dol(sita,n,hi,cutr,shl,t_var,t_amp); }

  if(t_bak==1){ TogeObj04_back01(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==2){ TogeObj04_back02(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==3){ TogeObj04_front08_01(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==4){ TogeObj04_front08_02(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==5){ TogeObj04_front08_03(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==6){ TogeObj04_front08_04(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==7){ TogeObj04_back03_01(sita,n,hi,cutr,shl,t_var,t_amp); } //����ȍ~���
  if(t_bak==8){ TogeObj04_back03_02(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==9){ TogeObj04_back03_03(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==10){ TogeObj04_back03_04(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==11){ TogeObj04_back03_05(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==12){ TogeObj04_back03_06(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==13){ TogeObj04_back03_07(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==14){ TogeObj04_back03_08(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==15){ TogeObj04_back03_09(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_bak==16){ TogeObj04_back03_10(sita,n,hi,cutr,shl,t_var,t_amp); }


  if(t_mid==1){ TogeObj04_mid01(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_mid==2){ TogeObj04_mid02(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_mid==3){ TogeObj04_mid03(sita,n,hi,cutr,shl,t_var,t_amp); }
  if(t_mid==4){ TogeObj04_mid04(sita,n,hi,cutr,shl,t_var,t_amp); }


  //�w�i�F�w��
  //(1.0������Ɏw��B�e�F�̔�ŐF�����܂�)
  rr=0.7; //��
  gg=0.45; //��
  bb=0.21; //��
  TogeObj04_bg(sita,n,hi,cutr,shl,t_var,t_amp,rr,gg,bb);


  glDepthMask(FALSE);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

  glDepthMask(TRUE);
  glDisable(GL_BLEND);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_bg(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp,double rr,double gg,double bb){
  //�o�b�N�O���E���h�̐F���w�肷��

  //glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(rr,gg,bb,1.0);
  //glEnable(GL_BLEND);

  sq_plate2(-20.0,-20.0,20.0,-20.0,20.0,20.0,-20.0,20.0,10.0);

  //glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front01(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j
  double r1,r2,r3,r4,r5,bet,b1,b2,b3,b4;
  double xx,yy,x1,y1,x2,y2,x3,y3,x4,y4,x5,y5;

  //���̒��S���W
  xx=0.0;
  yy=0.0;

  //���̑傫��
  r1=8.0;//���̒����̔���
  r2=3.0;//���̕��̔���
  r3=4.0;//�O�p�����̍���
  r4=r1-r3;
  r5=sqrt(r2*r2+r4*r4);
  bet=acos(r4/r5)*180/3.141592;
  b1=(sita+(int)bet)*3.14159/180.0;
  b2=(sita-(int)bet)*3.14159/180.0;
  b3=(sita+180-(int)bet)*3.14159/180.0;
  b4=(sita+180+(int)bet)*3.14159/180.0;

  x1=r1*cos(sita*3.14159/180.0);
  y1=r1*sin(sita*3.14159/180.0);

  x3=r5*cos(b1);
  y3=r5*sin(b1);
  x2=r5*cos(b2);
  y2=r5*sin(b2);

  x4=r5*cos(b3);
  y4=r5*sin(b3);
  x5=r5*cos(b4);
  y5=r5*sin(b4);


  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(0.0,0.0,1.0,0.7);
  glEnable(GL_BLEND);
  tri_plate(x1+xx,-1*y1+yy,x2+xx,-1*y2+yy,x3+xx,-1*y3+yy,-5.5);
  sq_plate2(x4+xx,-1.0*y4+yy,x3+xx,-1.0*y3+yy,x2+xx,-1.0*y2+yy,x5+xx,-1.0*y5+yy,-5.5);
  glDisable(GL_BLEND);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front01_01(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j
  double r1,r2,r3,r4,r5,bet,b1,b2,b3,b4;
  double xx,yy,x1,y1,x2,y2,x3,y3,x4,y4,x5,y5;

  //���̒��S���W
  xx=2.0;
  yy=-2.0;

  sita=45;

  //���̑傫��
  r1=8.0;//���̒����̔���
  r2=3.0;//���̕��̔���
  r3=4.0;//�O�p�����̍���
  r4=r1-r3;
  r5=sqrt(r2*r2+r4*r4);
  bet=acos(r4/r5)*180/3.141592;
  b1=(sita+(int)bet)*3.14159/180.0;
  b2=(sita-(int)bet)*3.14159/180.0;
  b3=(sita+180-(int)bet)*3.14159/180.0;
  b4=(sita+180+(int)bet)*3.14159/180.0;

  x1=r1*cos(sita*3.14159/180.0);
  y1=r1*sin(sita*3.14159/180.0);

  x3=r5*cos(b1);
  y3=r5*sin(b1);
  x2=r5*cos(b2);
  y2=r5*sin(b2);

  x4=r5*cos(b3);
  y4=r5*sin(b3);
  x5=r5*cos(b4);
  y5=r5*sin(b4);


  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(1.0,0.0,0.0,0.8);
  glEnable(GL_BLEND);
  tri_plate(x1+xx,-1*y1+yy,x2+xx,-1*y2+yy,x3+xx,-1*y3+yy,-5.5);
  sq_plate2(x4+xx,-1.0*y4+yy,x3+xx,-1.0*y3+yy,x2+xx,-1.0*y2+yy,x5+xx,-1.0*y5+yy,-5.5);
  glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front01_02(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j
  double r1,r2,r3,r4,r5,bet,b1,b2,b3,b4;
  double xx,yy,x1,y1,x2,y2,x3,y3,x4,y4,x5,y5;

  //���̒��S���W
  xx=2.0;
  yy=2.0;

  sita=-45;

  //���̑傫��
  r1=8.0;//���̒����̔���
  r2=3.0;//���̕��̔���
  r3=4.0;//�O�p�����̍���
  r4=r1-r3;
  r5=sqrt(r2*r2+r4*r4);
  bet=acos(r4/r5)*180/3.141592;
  b1=(sita+(int)bet)*3.14159/180.0;
  b2=(sita-(int)bet)*3.14159/180.0;
  b3=(sita+180-(int)bet)*3.14159/180.0;
  b4=(sita+180+(int)bet)*3.14159/180.0;

  x1=r1*cos(sita*3.14159/180.0);
  y1=r1*sin(sita*3.14159/180.0);

  x3=r5*cos(b1);
  y3=r5*sin(b1);
  x2=r5*cos(b2);
  y2=r5*sin(b2);

  x4=r5*cos(b3);
  y4=r5*sin(b3);
  x5=r5*cos(b4);
  y5=r5*sin(b4);


  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(0.0,0.0,1.0,0.8);
  glEnable(GL_BLEND);
  tri_plate(x1+xx,-1*y1+yy,x2+xx,-1*y2+yy,x3+xx,-1*y3+yy,-5.5);
  sq_plate2(x4+xx,-1.0*y4+yy,x3+xx,-1.0*y3+yy,x2+xx,-1.0*y2+yy,x5+xx,-1.0*y5+yy,-5.5);
  glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front02(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j
  double e1,e2,e3,e4,r,alh,blh,clh,sit,sit2,sit3,sit4,si[4];
  double xa,ya,xb,yb,xc,yc,xd,yd,x[4],y[4],al[4];
  int sita2,sita3,sita4,fi[4],i,xx,yy,aa;

  //���̑傫��
  e1=5.0;//���̒���
  e2=3.0;//���̕��̔���

  fi[0]=sita;    if(fi[0]>60){ fi[0]=fi[0] % 60; }
  fi[1]=sita+10; if(fi[1]>60){ fi[1]=fi[1] % 60; }
  fi[2]=sita+20; if(fi[2]>60){ fi[2]=fi[2] % 60; }
  fi[3]=sita+30; if(fi[3]>60){ fi[3]=fi[3] % 60; }
  si[0]=(double)fi[0];
  si[1]=(double)fi[1];
  si[2]=(double)fi[2];
  si[3]=(double)fi[3];

  for(i=0;i<4;i++){
    if((fi[i]>=0)&&(fi[i]<30)){
      x[i]=-14.0+si[i]/2.0;
      y[i]=0.0;
      al[i]=0.0;
    }
    if((fi[i]>=30)&&(fi[i]<40)){
      x[i]=1.0+(si[i]-30.0)/2.0;
      y[i]=0.0+(si[i]-30.0)/2.0;
      al[i]=(si[i]-30.0)*9.0;
    }
    if((fi[i]>=40)&&(fi[i]<60)){
      x[i]=6.0;
      y[i]=5.0+(si[i]-40.0)/2.0;
      al[i]=90.0;
    }

  }

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);


  glEnable(GL_BLEND);


  color_set(1.0,0.0,0.0,0.7);
  tri_plate2(x[0],y[0],e1,e2,al[0],-5.5);
  color_set(0.0,0.0,1.0,0.7);
  tri_plate2(x[1],y[1],e1,e2,al[1],-5.5);
  color_set(1.0,0.0,0.0,0.7);
  tri_plate2(x[2],y[2],e1,e2,al[2],-5.5);
  color_set(0.0,0.0,1.0,0.7);
  tri_plate2(x[3],y[3],e1,e2,al[3],-5.5);


  glDisable(GL_BLEND);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front03(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j
  double e1,e2,e3,e4,r,alh,blh,clh,sit,sit2,sit3,sit4,si[4];
  double xa,ya,xb,yb,xc,yc,xd,yd,x[4],y[4],al[4];
  int sita2,sita3,sita4,fi[4],i;

  //���̑傫��
  e1=5.0;//���̒���
  e2=3.0;//���̕��̔���

  fi[0]=sita;    if(fi[0]>60){ fi[0]=fi[0] % 60; }
  fi[1]=sita+10; if(fi[1]>60){ fi[1]=fi[1] % 60; }
  fi[2]=sita+20; if(fi[2]>60){ fi[2]=fi[2] % 60; }
  fi[3]=sita+30; if(fi[3]>60){ fi[3]=fi[3] % 60; }
  si[0]=(double)fi[0];
  si[1]=(double)fi[1];
  si[2]=(double)fi[2];
  si[3]=(double)fi[3];

  for(i=0;i<4;i++){
    if((fi[i]>=0)&&(fi[i]<30)){
      x[i]=-14.0+si[i]/2.0;
      y[i]=0.0;
      al[i]=0.0;
    }
    if((fi[i]>=30)&&(fi[i]<40)){
      x[i]=1.0+(si[i]-30.0)/2.0;
      y[i]=0.0-(si[i]-30.0)/2.0;
      al[i]=-(si[i]-30.0)*9.0;
    }
    if((fi[i]>=40)&&(fi[i]<=60)){
      x[i]=6.0;
      y[i]=-5.0-(si[i]-40.0)/2.0;
      al[i]=-90.0;
    }
  }

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);


  glEnable(GL_BLEND);

   color_set(1.0,0.0,0.0,0.7);
  tri_plate2(x[0],y[0],e1,e2,al[0],-5.5);
  color_set(0.0,0.0,1.0,0.7);
  tri_plate2(x[1],y[1],e1,e2,al[1],-5.5);
  color_set(1.0,0.0,0.0,0.7);
  tri_plate2(x[2],y[2],e1,e2,al[2],-5.5);
  color_set(0.0,0.0,1.0,0.7);
  tri_plate2(x[3],y[3],e1,e2,al[3],-5.5);

  glDisable(GL_BLEND);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front04(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j
  double e1,e2,e3,e4,r,alh,blh,clh,sit,sit2,sit3,sit4,si[4];
  double xa,ya,xb,yb,xc,yc,xd,yd,x[4],y[4],z[4],al[4];
  int sita2,sita3,sita4,fi[4],i;

  //���̑傫��
  e1=5.0;//���̒���
  e2=3.0;//���̕��̔���

  fi[0]=sita;    if(fi[0]>60){ fi[0]=fi[0] % 60; }
  fi[1]=sita+10; if(fi[1]>60){ fi[1]=fi[1] % 60; }
  fi[2]=sita+20; if(fi[2]>60){ fi[2]=fi[2] % 60; }
  fi[3]=sita+30; if(fi[3]>60){ fi[3]=fi[3] % 60; }
  si[0]=(double)fi[0];
  si[1]=(double)fi[1];
  si[2]=(double)fi[2];
  si[3]=(double)fi[3];

  for(i=0;i<4;i++){
    if((fi[i]>=0)&&(fi[i]<30)){
      x[i]=0.0;
      y[i]=-10.0+si[i]/2.0;
      al[i]=90.0;
      z[i]=-5.5;
    }
    if((fi[i]>=30)&&(fi[i]<=60)){
      x[i]=0.0;
      y[i]=5.0;
      al[i]=90.0;
      z[i]=-5.6;
    }
  }

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);


  glEnable(GL_BLEND);


  color_set(1.0,0.0,0.0,0.7);
  tri_plate2(x[0],y[0],e1,e2,al[0],z[0]);
  color_set(0.0,0.0,1.0,0.7);
  tri_plate2(x[1],y[1],e1,e2,al[1],z[1]);
  color_set(1.0,0.0,0.0,0.7);
  tri_plate2(x[2],y[2],e1,e2,al[2],z[2]);
  color_set(0.0,0.0,1.0,0.7);
  tri_plate2(x[3],y[3],e1,e2,al[3],z[3]);


  glDisable(GL_BLEND);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front05(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j
  double e1,e2,e3,e4,r,alh,blh,clh,sit,sit2,sit3,sit4,si[4];
  double xa,ya,xb,yb,xc,yc,xd,yd,x[4],y[4],z[4],al[4];
  int sita2,sita3,sita4,fi[4],i;

  //���̑傫��
  e1=5.0;//���̒���
  e2=3.0;//���̕��̔���

  fi[0]=sita;    if(fi[0]>60){ fi[0]=fi[0] % 60; }
  fi[1]=sita+10; if(fi[1]>60){ fi[1]=fi[1] % 60; }
  fi[2]=sita+20; if(fi[2]>60){ fi[2]=fi[2] % 60; }
  fi[3]=sita+30; if(fi[3]>60){ fi[3]=fi[3] % 60; }
  si[0]=(double)fi[0];
  si[1]=(double)fi[1];
  si[2]=(double)fi[2];
  si[3]=(double)fi[3];

  for(i=0;i<4;i++){
    if((fi[i]>=0)&&(fi[i]<30)){
      x[i]=0.0;
      y[i]=10.0-si[i]/2.0;
      al[i]=-90.0;
      z[i]=-5.5;
    }
    if((fi[i]>=30)&&(fi[i]<=60)){
      x[i]=0.0;
      y[i]=-5.0;
      al[i]=-90.0;
      z[i]=-5.6;
    }
  }

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  glEnable(GL_BLEND);


  color_set(1.0,0.0,0.0,0.7);
  tri_plate2(x[0],y[0],e1,e2,al[0],z[0]);
  color_set(0.0,0.0,1.0,0.7);
  tri_plate2(x[1],y[1],e1,e2,al[1],z[1]);
  color_set(1.0,0.0,0.0,0.7);
  tri_plate2(x[2],y[2],e1,e2,al[2],z[2]);
  color_set(0.0,0.0,1.0,0.7);
  tri_plate2(x[3],y[3],e1,e2,al[3],z[3]);


  glDisable(GL_BLEND);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front06(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�K�[���c�j

  color_set(0.0,0.0,0.0,0.9);
  sq_plate(-9,-8,-15,2,-5.5);
  sq_plate(-7,-6,-15,0,-5.5);
  sq_plate(-5,-4,-15,-2,-5.5);
  sq_plate(-3,-2,-15,-4,-5.5);

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);
  glEnable(GL_BLEND);
  color_set(1.0,1.0,1.0,0.9);
  sq_plate(-15,15,-15,15,1.5);
  glDisable(GL_BLEND);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front07(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�܁j

  double vit[8];

  color_set(0.0,0.0,1.0,0.9);


  vit[0]=sita % 90;
  vit[1]=(sita+23) % 90;
  vit[2]=(sita+45) % 90;
  vit[3]=(sita+68) % 90;

  drop_plate(5.2,1.0-vit[0]/6.5,2,1,90,-4.0);
  drop_plate(-5.2,1.0-vit[1]/6.5,2,1,90,-4.0);
  drop_plate(5.2,1.0-vit[2]/6.5,2,1,90,-4.0);
  drop_plate(-5.2,1.0-vit[3]/6.5,2,1,90,-4.0);



}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front08_01(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g/�o�b�N�i���j
  double r1,r2,r3,r4,r5,bet,b1,b2,b3,b4;
  double xx,yy,x1,y1,x2,y2,x3,y3,x4,y4,x5,y5;

  //���S���W
  xx=0.0;
  yy=0.0;

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(1.0,0.0,0.0,0.8);
  glEnable(GL_BLEND);

  glPushMatrix();
    glTranslatef(xx,yy,-3.0);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 5.0, 7.0, 40, 40);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();

  glPushMatrix();
    glTranslatef(xx,yy,-3.0);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 9.0, 11.0, 40, 40);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();

  glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front08_02(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g/�o�b�N�i���j
  double r1,r2,r3,r4,r5,bet,b1,b2,b3,b4;
  double xx,yy,x1,y1,x2,y2,x3,y3,x4,y4,x5,y5;

  //���S���W
  xx=0.0;
  yy=0.0;

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(1.0,0.0,0.0,0.8);
  glEnable(GL_BLEND);

  glPushMatrix();
    glTranslatef(xx,yy,-3.0);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 7.0, 9.0, 40, 40);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();

  glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front08_03(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g/�o�b�N�i�~�j
  double xx,yy,l,t,r,s,si[8],x[8],y[8];
  int i;

  //���S���W
  xx=0.0;
  yy=0.0;

  //�~�̖_�̒����̔���
  l=11.0;

  //�~�̖_�̕��̔���
  t=1.0;

  r=sqrt(l*l+t*t);

  s=acos(l/r)*180/3.141592;

  si[0]=45-s;
  si[1]=45+s;
  si[2]=135-s;
  si[3]=135+s;
  si[4]=225-s;
  si[5]=225+s;
  si[6]=315-s;
  si[7]=315+s;

  for(i=0;i<8;i++){
    x[i]=xx+r*cos(si[i]*3.141592/180.0);
    y[i]=yy+r*sin(si[i]*3.141592/180.0);
  }

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(1.0,0.0,0.0,0.8);
  glEnable(GL_BLEND);

  sq_plate2(x[0],-1.0*y[0],x[5],-1.0*y[5],x[4],-1.0*y[4],x[1],-1.0*y[1],-5.5);
  sq_plate2(x[2],-1.0*y[2],x[7],-1.0*y[7],x[6],-1.0*y[6],x[3],-1.0*y[3],-5.5);

  glDisable(GL_BLEND);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front08_04(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g/�o�b�N�i���j
  double x[8],y[8];

  x[0]=0.0;   y[0]=8.0;
  x[1]=0.0;   y[1]=3.5;
  x[2]=-9.0;  y[2]=-8.0;
  x[3]=-6.5;  y[3]=-8.0;
  x[4]=6.5;   y[4]=-8.0;
  x[5]=9.0;   y[5]=-8.0;
  x[6]=-7.0;  y[6]=-6.0;
  x[7]=7.0;   y[7]=-6.0;

  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(1.0,0.0,0.0,0.8);
  glEnable(GL_BLEND);

  sq_plate2(x[0],-1.0*y[0],x[1],-1.0*y[1],x[3],-1.0*y[3],x[2],-1.0*y[2],-5.5);
  sq_plate2(x[0],-1.0*y[0],x[5],-1.0*y[5],x[4],-1.0*y[4],x[1],-1.0*y[1],-5.5);
  sq_plate2(x[7],-1.0*y[7],x[4],-1.0*y[4],x[3],-1.0*y[3],x[6],-1.0*y[6],-5.5);

  glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front_yen(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i\\�j
  double f1x,f1y,f2x,f2y;

  f1x=5.0; f1y=-3.0;   //�E�̍��ڂ̌��_
  f2x=-5.0; f2y=-3.0;  //���̍��ڂ̌��_

  color_set(0.0,0.0,0.0,0.9);
  sq_plate(f1x-2.0,f1x+2.0,f1y+0.0,f1y-1.0,-5.5);
  sq_plate(f1x-2.0,f1x+2.0,f1y+0.5,f1y+1.5,-5.5);
  sq_plate(f1x-0.5,f1x+0.5,f1y+0.0,f1y+2.25,-5.5);
  sq_plate2(f1x-0.25,f1y-1.0,f1x+1.0,f1y-3.5,f1x+2.0,f1y-3.0,f1x+1.0,f1y-1.0,-5.5);
  sq_plate2(f1x+0.25,f1y-1.0,f1x-1.0,f1y-3.5,f1x-2.0,f1y-3.0,f1x-1.0,f1y-1.0,-5.5);

  sq_plate(f2x-2.0,f2x+2.0,f2y+0.0,f2y-1.0,-5.5);
  sq_plate(f2x-2.0,f2x+2.0,f2y+0.5,f2y+1.5,-5.5);
  sq_plate(f2x-0.5,f2x+0.5,f2y+0.0,f2y+2.25,-5.5);
  sq_plate2(f2x-0.25,f2y-1.0,f2x+1.0,f2y-3.5,f2x+2.0,f2y-3.0,f2x+1.0,f2y-1.0,-5.5);
  sq_plate2(f2x+0.25,f2y-1.0,f2x-1.0,f2y-3.5,f2x-2.0,f2y-3.0,f2x-1.0,f2y-1.0,-5.5);
}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front_sho(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�����j
  double f1x,f1y,f2x,f2y;

  f1x=5.0; f1y=-3.0;   //�E�̍��ڂ̌��_
  f2x=-5.0; f2y=-3.0;  //���̍��ڂ̌��_

  color_set(0.0,0.0,0.0,0.9);
  sq_plate(f1x-0.5,f1x+0.5,f1y-3.5,f1y+1.0,-5.5);
  sq_plate2(f1x-3.05,f1y-0.6,f1x-1.8,f1y-2.5,f1x-0.8,f1y-2.0,f1x-1.8,f1y-0.0,-5.5);
  sq_plate2(f1x+3.05,f1y-0.6,f1x+1.8,f1y-2.5,f1x+0.8,f1y-2.0,f1x+1.8,f1y+0.0,-5.5);

  sq_plate(f2x-0.5,f2x+0.5,f2y-3.5,f2y+1.0,-5.5);
  sq_plate2(f2x-3.05,f2y-0.6,f2x-1.8,f2y-2.5,f2x-0.8,f2y-2.0,f2x-1.8,f2y-0.0,-5.5);
  sq_plate2(f2x+3.05,f2y-0.6,f2x+1.8,f2y-2.5,f2x+0.8,f2y-2.0,f2x+1.8,f2y+0.0,-5.5);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front_dai(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j
  double f1x,f1y,f2x,f2y;

  f1x=5.0; f1y=-3.0;   //�E�̍��ڂ̌��_
  f2x=-5.0; f2y=-3.0;  //���̍��ڂ̌��_

  color_set(0.0,0.0,0.0,0.9);
  sq_plate(f1x-0.5,f1x+0.5,f1y-4.0,f1y-2.8,-5.5);
  sq_plate(f1x-2.5,f1x+2.5,f1y-1.8,f1y-2.8,-5.5);
  sq_plate2(f1x-1.55,f1y-0.6,f1x-0.3,f1y-2.5,f1x+0.7,f1y-2.0,f1x-0.3,f1y-0.0,-5.5);
  sq_plate2(f1x+1.55,f1y-0.6,f1x+0.3,f1y-2.5,f1x-0.7,f1y-2.0,f1x+0.3,f1y+0.0,-5.5);
  sq_plate2(f1x-1.55,f1y-0.6,f1x-0.3,f1y-0.0,f1x-1.2,f1y+1.0,f1x-2.8,f1y+1.0,-5.5);
  sq_plate2(f1x+1.55,f1y-0.6,f1x+0.3,f1y-0.0,f1x+1.2,f1y+1.0,f1x+2.8,f1y+1.0,-5.5);

  sq_plate(f2x-0.5,f2x+0.5,f2y-4.0,f2y-2.8,-5.5);
  sq_plate(f2x-2.5,f2x+2.5,f2y-1.8,f2y-2.8,-5.5);
  sq_plate2(f2x-1.55,f2y-0.6,f2x-0.3,f2y-2.5,f2x+0.7,f2y-2.0,f2x-0.3,f2y-0.0,-5.5);
  sq_plate2(f2x+1.55,f2y-0.6,f2x+0.3,f2y-2.5,f2x-0.7,f2y-2.0,f2x+0.3,f2y+0.0,-5.5);
  sq_plate2(f2x-1.55,f2y-0.6,f2x-0.3,f2y-0.0,f2x-1.2,f2y+1.0,f2x-2.8,f2y+1.0,-5.5);
  sq_plate2(f2x+1.55,f2y-0.6,f2x+0.3,f2y-0.0,f2x+1.2,f2y+1.0,f2x+2.8,f2y+1.0,-5.5);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front_dol(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i$$�j
  double r,f1x,f1y,f2x,f2y,db;
  int i;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  f1x=5.0; f1y=-3.0;   //�E�̍��ڂ̌��_
  f2x=-5.0; f2y=-3.0;  //���̍��ڂ̌��_

  color_set(0.0,0.0,0.0,0.9);

  r=1.6;
  for(i=0;i<30;i++){
  glPushMatrix();
    glTranslatef(f1x+0.7+r*cos(i*6*3.141592/180.0),f1y-2.7-r*sin(i*6*3.141592/180.0),-2);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  }
  for(i=0;i<30;i++){
  glPushMatrix();
    glTranslatef(f2x-0.7+r*cos(i*6*3.141592/180.0),f2y-2.7-r*sin(i*6*3.141592/180.0),-2);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  }
  for(i=0;i<30;i++){
  glPushMatrix();
    glTranslatef(f1x+0.7+r*cos((i*6+180)*3.141592/180.0),f1y-0.8-r*sin((i*6+180)*3.141592/180.0),-2);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  }
  for(i=0;i<30;i++){
  glPushMatrix();
    glTranslatef(f2x-0.7+r*cos((i*6+180)*3.141592/180.0),f2y-0.8-r*sin((i*6+180)*3.141592/180.0),-2);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  }

  sq_plate(f1x-0.5,f1x+0.5,f1y-4.1,f1y+1.6,-5.5);
  sq_plate2(f1x-1.7,f1y-1.9,f1x-1.0,f1y-2.4,f1x+1.8,f1y-0.4,f1x+1.0,f1y+0.0,-5.5);

  sq_plate(f2x-0.5,f2x+0.5,f2y-4.1,f2y+1.6,-5.5);
  sq_plate2(f2x-1.7,f2y-1.9,f2x-1.0,f2y-2.4,f2x+1.8,f2y-0.4,f2x+1.0,f2y+0.0,-5.5);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front_hand02(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�@�ق���j�@�̂�
  //�����o��o�O��@�����͏������B

  double r,r1,r2,db,h,v,l,d;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  sita=sita % 180;

  //�@
  r=0.4*sin(sita*3.14159/180);
  if(sita>90){ r=0.4*sin(90*3.14159/180); }
  r1=1.5*sin(sita*3.14159/180);
  if(sita>90){ r1=1.5*sin(90*3.14159/180); }

  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(1.0+r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(-1.0-r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();



  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(1.0+r1,0.5,-3.8);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN3=gluNewQuadric();
    gluDisk(quadricHAN3, 0.0*db, 0.3*db, cutr, 30);
    gluDeleteQuadric(quadricHAN3);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(-1.0-r1,0.5,-3.8);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN4=gluNewQuadric();
    gluDisk(quadricHAN4, 0.0*db, 0.3*db, cutr, 30);
    gluDeleteQuadric(quadricHAN4);
  glPopMatrix();


  //�@��
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(1.0+r1,1.9,-3.8);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, (0.2+r1)*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-1.0-r1,1.9,-3.8);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 0.0*db, (0.2+r1)*db, cutr, 30);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();
}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front_hand02_h(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�@�ق���j��̂�

  double r,r1,r2,db,h,v,l,d;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  sita=sita % 180;
  //��
  h=0.0; v=5.0; l=0.0;
  if(sita<90){ h=15.0;}
  if((sita>=90)&&(sita<120)){ h=2.5; v=12.0-((double)sita-90.0)/4.5;}
  if((sita>=120)&&(sita<180)){ h=2.5; v=12.0-(120.0-90.0)/4.5;
    if((sita>=120)&&(sita<135)){ l=sita-120; }
    if((sita>=135)&&(sita<150)){ l=15-(sita-135); }
    if((sita>=150)&&(sita<165)){ l=sita-150; }
    if((sita>=165)&&(sita<180)){ l=15-(sita-165); }
    l=l*2.0;
  }
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(h,2.0+v,-3.2);
    glRotatef(l,0,1,0);
    glScalef(1.5,1.8,1.0);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(h,v,-3.2);
    glRotatef(l,0,0,0);
    glScalef(1.2,2.5,1.0);
    GLUquadric* quadricKYU12=gluNewQuadric();
    gluSphere(quadricKYU12, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU12);
  glPopMatrix();

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front_hand01(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i����j

  double r,r1,r2,db,h;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  i=sita % 4;
  if(i<2){ i=i*16; }
  else{ i=(4-i)*16; }
  h=(double)i/12.0;

  //��
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(2.0+h,5.0,-3.0);
    glRotatef(i,0,0,1);
    glScalef(1.5,1.8,1.0);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(2.0+h,3.0,-3.0);
    glRotatef(i,0,0,1);
    glScalef(1.2,2.5,1.0);
    GLUquadric* quadricKYU12=gluNewQuadric();
    gluSphere(quadricKYU12, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU12);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-2.0-h,5.0,-3.0);
    glRotatef(-1*i,0,0,1);
    glScalef(1.5,1.8,1.0);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-2.0-h,3.0,-3.0);
    glRotatef(-1*i,0,0,1);
    glScalef(1.2,2.5,1.0);
    GLUquadric* quadricKYU22=gluNewQuadric();
    gluSphere(quadricKYU22, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU22);
  glPopMatrix();

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front09(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�@���j

  double si;
  double r,r1;

  color_set(1.0,0.0,0.0,0.9);
  sita= sita % 90;
  si= (double)sita/11.0;
  sq_plate(-3.0,-2.0,1.0,1.0+si,-3.5);

  glPushMatrix();
    color_set(1.0,0.0,0.0,0.9);
    glTranslatef(-2.5,1.0+si,-3.5);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN3=gluNewQuadric();
    gluDisk(quadricHAN3, 0.0, 0.5, cutr, 30);
    gluDeleteQuadric(quadricHAN3);
  glPopMatrix();


  //�@
  r=0.4;
  r1=1.5;

  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(1.0+r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(-1.0-r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //�@��
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(1.0+r1,1.9,-3.8);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, (0.2+r1), cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-1.0-r1,1.9,-3.8);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 0.0, (0.2+r1), cutr, 30);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();
}


//---------------------------------------------------------------------------
void Toge::TogeObj04_front10(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�@�g���j

  double si;
  double r,r1;

  //�@
  r=0.4;
  r1=1.5;

  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(1.0+r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(-1.0-r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //�@��
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(1.0+r1,1.9,-3.8);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, (0.2+r1), cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-1.0-r1,1.9,-3.8);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 0.0, (0.2+r1), cutr, 30);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();
}

//---------------------------------------------------------------------------
void Toge::TogeObj04_front11(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i���j

  double vit[8];

  color_set(1.0,1.0,1.0,0.9);


  vit[0]=sita % 90;
  vit[1]=(sita+23) % 90;
  vit[2]=(sita+45) % 90;
  vit[3]=(sita+68) % 90;

  drop_plate(8.2,1.0-vit[0]/6.5,2,1,90,-4.0);
  //drop_plate(-5.2,1.0-vit[1]/6.5,2,1,90,-4.0);
  drop_plate(8.2,1.0-vit[2]/6.5,2,1,90,-4.0);
  //drop_plate(-5.2,1.0-vit[3]/6.5,2,1,90,-4.0);



}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front12(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�ڂ̒��̐��ƕ@�̌��j

  double d,al,rg,rrg,x[5],y[5],xx[5],yy[5],xd,yd;
  double r,r1;
  int i,j;

  d=3.14159/180;
  al=18;

  //�����̌܊p�`�̔��a
  rg=1.5;
  //���̐�܂ł̔��a
  rrg=3.0;
  //���̒��S���W
  xd=5.7;  yd=4.7;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(1.0,1.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-2.1);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-2.1);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-2.1);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-2.1);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-2.1);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-2.1);

  //���̒��S���W
  xd=-5.7;  yd=4.7;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(1.0,1.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-2.1);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-2.1);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-2.1);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-2.1);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-2.1);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-2.1);

  //�����̌܊p�`�̔��a
  rg=0.5;
  //���̐�܂ł̔��a
  rrg=1.5;
  //���̒��S���W
  xd=5.5;  yd=-3.6;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(1.0,1.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-5.4);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-5.4);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-5.4);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-5.4);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-5.4);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-5.4);

  //�@
  r=0.4;
  r1=1.5;

  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(1.0+r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(-1.0-r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //�@��
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(1.0+r1,1.6,-4.2);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, (0.2+r1), cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-1.0-r1,1.6,-4.2);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 0.0, (0.2+r1), cutr, 30);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_front13(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�t�����g�i�ڂ̒��̐��ƕ@�̌��j

  double d,al,rg,rrg,x[5],y[5],xx[5],yy[5],xd,yd;
  double r,r1;
  int i,j;

  d=3.14159/180;
  al=18;

  //�����̌܊p�`�̔��a
  rg=1.5;
  //���̐�܂ł̔��a
  rrg=3.0;
  //���̒��S���W
  xd=5.7;  yd=4.7;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(1.0,1.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-2.1);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-2.1);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-2.1);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-2.1);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-2.1);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-2.1);

  //���̒��S���W
  xd=-5.7;  yd=4.7;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(1.0,1.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-2.1);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-2.1);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-2.1);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-2.1);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-2.1);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-2.1);

  //�����̌܊p�`�̔��a
  rg=1.7;
  //���̐�܂ł̔��a
  rrg=3.2;
  //���̒��S���W
  xd=5.7;  yd=4.7;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(0.0,0.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-2.0);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-2.0);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-2.0);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-2.0);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-2.0);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-2.0);

  //���̒��S���W
  xd=-5.7;  yd=4.7;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(0.0,0.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-2.0);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-2.0);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-2.0);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-2.0);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-2.0);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-2.0);


  //�����̌܊p�`�̔��a
  rg=0.5;
  //���̐�܂ł̔��a
  rrg=1.5;
  //���̒��S���W
  xd=5.5;  yd=-3.6;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(1.0,1.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-5.4);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-5.4);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-5.4);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-5.4);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-5.4);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-5.4);

  //�����̌܊p�`�̔��a
  rg=0.7;
  //���̐�܂ł̔��a
  rrg=1.7;
  //���̒��S���W
  xd=5.5;  yd=-3.6;

  for(i=0;i<5;i++){
    x[i]=xd+rg*cos((i*72-al)*d);
    y[i]=yd+rg*sin((i*72-al)*d);
    xx[i]=xd+rrg*cos((i*72-al+36)*d);
    yy[i]=yd+rrg*sin((i*72-al+36)*d);
  }

  color_set(0.0,0.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-5.3);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-5.3);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-5.3);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-5.3);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-5.3);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-5.3);

  //�@
  r=0.4;
  r1=1.5;

  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(1.0+r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(-1.0-r1,0.5,-1.8);
    glScalef(1+r,1+r,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //�@��
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(1.0+r1,1.6,-4.2);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, (0.2+r1), cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-1.0-r1,1.6,-4.2);
    glRotatef(220,1,0,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 0.0, (0.2+r1), cutr, 30);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back01(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�o�b�N
  double rr;
  int i;

  glPushMatrix();
    color_set(1.0,0.0,0.0,1.0);
    glTranslatef(0.0,15.0,3.5);
    Kyu(7.0,1.0,1.0);
  glPopMatrix();

  color_set(1.0,1.0,0.0,1.0);
  sq_plate(-15.0,15.0,-15.0,15.0,1.1);

  color_set(1.0,0.0,0.0,1.0);
  rr=30.0;
  for(i=0;i<12;i++){
    tri_plate(0.0,15.0,rr*cos((sita+15+i*30)*3.14159/180),-1.0*rr*sin((sita+15+i*30)*3.14159/180),rr*cos((sita+i*30)*3.14159/180),-1.0*rr*sin((sita+i*30)*3.14159/180),1.0);
  }
}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back02(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�o�b�N(����`��)
  double d,al,r,rr,x[5],y[5],xx[5],yy[5],xd,yd;
  int i;

  d=3.14159/180;
  al=18;
  //�����̌܊p�`�̔��a
  r=6.0;
  //���̐�܂ł̔��a
  rr=11.0;
  //���̒��S���W
  xd=0.0;  yd=-1.0;


  for(i=0;i<5;i++){
    x[i]=xd+r*cos((i*72-al)*d);
    y[i]=yd+r*sin((i*72-al)*d);
    xx[i]=xd+rr*cos((i*72-al+36)*d);
    yy[i]=yd+rr*sin((i*72-al+36)*d);
  }

  color_set(1.0,1.0,0.0,1.0);
  penta_plate(x[0],-1*y[0],x[1],-1*y[1],x[2],-1*y[2],x[3],-1*y[3],x[4],-1*y[4],-1.1);
  tri_plate(xx[0],-1*yy[0],x[0],-1*y[0],x[1],-1*y[1],-1.1);
  tri_plate(xx[1],-1*yy[1],x[1],-1*y[1],x[2],-1*y[2],-1.1);
  tri_plate(xx[2],-1*yy[2],x[2],-1*y[2],x[3],-1*y[3],-1.1);
  tri_plate(xx[3],-1*yy[3],x[3],-1*y[3],x[4],-1*y[4],-1.1);
  tri_plate(xx[4],-1*yy[4],x[4],-1*y[4],x[0],-1*y[0],-1.1);

  //���̐�Ɋۂ�����
  for(i=0;i<5;i++){
    glPushMatrix();
     color_set(1.0,1.0,0.0,1.0);
     glTranslatef(xx[i],-1*yy[i],-1.1);
     Kyu(1.2,1.0,1.0);
    glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_01(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(-15.0,15.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,0.0,-15.0,1.1);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_02(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(-15.0,15.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,0.0,15.0,1.1);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_03(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(15.0,0.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,15.0,-15.0,1.1);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_04(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(-15.0,0.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,15.0,-15.0,1.1);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_05(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(15.0,0.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,15.0,0.0,1.1);
  sq_plate(-1.0,1.0,-1.0,1.0,1.1);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_06(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(-15.0,0.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,15.0,0.0,1.1);
  sq_plate(-1.0,1.0,-1.0,1.0,1.1);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_07(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(15.0,0.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,-15.0,0.0,1.1);
  sq_plate(-1.0,1.0,-1.0,1.0,1.1);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_08(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(-15.0,0.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,-15.0,0.0,1.1);
  sq_plate(-1.0,1.0,-1.0,1.0,1.1);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_09(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���j

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(-15.0,15.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,15.0,-15.0,1.1);

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_back03_10(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //��Ղ������i���̒��Ɂ��j
  double xx,yy;

  color_set(0.0,0.0,0.0,0.0);
  sq_plate(-15.0,15.0,-1.0,1.0,1.1);
  sq_plate(-1.0,1.0,15.0,-15.0,1.1);

  //���S���W
  xx=0.0;
  yy=0.0;

  color_set(0.0,0.0,0.0,1.0);

  glPushMatrix();
    glTranslatef(xx,yy,1.1);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, 3, 40, 40);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_mid01(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�~�b�h�i�͌�̍��΁j
  double xx,yy;

  //���S���W
  xx=0.0;
  yy=0.0;

  //glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(0.0,0.0,0.0,1.0);
//  glEnable(GL_BLEND);

  glPushMatrix();
    glTranslatef(xx,yy,-1.0);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, 11.5, 40, 40);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();

//  glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_mid02(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�~�b�h�i�͌�̔��΁j
  double xx,yy;

  //���S���W
  xx=0.0;
  yy=0.0;

  //glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(1.0,1.0,1.0,1.0);
//  glEnable(GL_BLEND);

  glPushMatrix();
    glTranslatef(xx,yy,-1.0);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, 11.5, 40, 40);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();

//  glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_mid03(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�~�b�h�i�͌�̍��΁@�k����j
  double xx,yy,sp;

  //���S���W
  if(0==sita % 3){ sp=0.5;}
  if(1==sita % 3){ sp=0.0;}
  if(2==sita % 3){ sp=-0.5;}

  xx=0.0+sp;
  yy=0.0;

  //glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(0.0,0.0,0.0,1.0);
//  glEnable(GL_BLEND);

  glPushMatrix();
    glTranslatef(xx,yy,-1.0);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, 11.5, 40, 40);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();

//  glDisable(GL_BLEND);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_mid04(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�~�b�h�i�͌�̔��΁@�k����j
  double xx,yy,sp;

  //���S���W
  if(0==sita % 3){ sp=0.5;}
  if(1==sita % 3){ sp=0.0;}
  if(2==sita % 3){ sp=-0.5;}

  xx=0.0+sp;
  yy=0.0;

  //glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  color_set(1.0,1.0,1.0,1.0);
//  glEnable(GL_BLEND);

  glPushMatrix();
    glTranslatef(xx,yy,-1.0);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0, 11.5, 40, 40);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();

//  glDisable(GL_BLEND);

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_29(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(�Жڑ傫��)
  double xx1,xx2,yy1,yy2,x1,x2,x3,x4,y1,y2,y3,y4,y5,y6,r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 3.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();


    xx1=6+2*hi[4];
    yy1=-5+2*hi[5];
    xx2=-6+2*hi[6];
    yy2=-5+2*hi[7];
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(xx1,yy1,-1.5);
    glRotatef(180,0,1,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.6*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(xx2,yy2,-1.5);
    glRotatef(180,0,1,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 0.0*db, 0.6*db, cutr, 30);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-4);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 1.2*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();


  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_28(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u�H�i�����̋�̒��ɂS�j
  double x1,y1,x2,y2;

  x1=0.0; y1=0.0;  //��̊�_
  x2=0.0; y2=0.0;  //�S�̊�_

  color_set(1.0,1.0,0.0,1.0);
  penta_plate(x1+0,y1-10,x1+6,y1-7,x1+10,y1+10,x1-10,y1+10,x1-6,y1-7,-1.1);
  color_set(0.0,0.0,0.0,1.0);
  sq_plate2(x2+0,y2-5,x2+2,y2-5,x2+2,y2+8,x2+0,y2+8,-1.3);
  sq_plate2(x2-6,y2+3,x2+5,y2+3,x2+5,y2+5,x2-6,y2+5,-1.3);
  sq_plate2(x2+0,y2-5,x2+2,y2-4,x2-4,y2+4,x2-6,y2+3,-1.3);

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_27(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u�i�����@�����N�̋��т݂����Ȋ�j
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glRotatef(-5,0,0,1);
    glScalef(1+hi[0],3+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glRotatef(35,0,0,1);
    glScalef(2+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-3);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 1.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-3);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-4,-3);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-1.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 3.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
  //  if(t_amp>shl){
      glTranslatef(0,-3,-2);
      glRotatef(5,0,0,1);
      glScalef(1.5,1,1);
  //  }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
 //   if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
 //   }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
 // if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU10=gluNewQuadric();
    gluSphere(quadricKYU10, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU10);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
//  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_26(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u�i��S�̂�傫���j
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(7.5+2*hi[4],-6+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 3.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-7.5+2*hi[6],-6+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 3.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(7.0+1.4*sin(sita*3.14159/180),-6,-3.5);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.6*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-7.0-1.4*sin(sita*3.14159/180),-6,-3.5);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.6*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-1.6,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,1.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],7,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],8.3,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_25(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u�i��S�̂��������j
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(4+2*hi[4],-3+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 1.3*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-4+2*hi[6],-3+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 1.3*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(4+0.8*sin(sita*3.14159/180),-3,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.2*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-4-0.8*sin(sita*3.14159/180),-3,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.2*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 1.1*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.1*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],2.7,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 1.1*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],3.2,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 1.1*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_24(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(�ڂ��҂�)
  double xx1,xx2,yy1,yy2,x1,x2,x3,x4,y1,y2,y3,y4,y5,y6,r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 3.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 3.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();


    xx1=6+2*hi[4];
    yy1=-5+2*hi[5];
    xx2=-6+2*hi[6];
    yy2=-5+2*hi[7];
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(xx1,yy1,-1.5);
    glRotatef(180,0,1,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.6*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(xx2,yy2,-1.5);
    glRotatef(180,0,1,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 0.0*db, 0.6*db, cutr, 30);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();


  //����
  r=3.5;

    color_set(0.0,0.0,0.0,0.5);
    x1=4.7;
    x2=x1+r*cos(30.0*3.141592/180.0);
    y1=-4.4;
    y2=-4.4-r*sin(30.0*3.141592/180.0);
    sq_plate2(x1-1.0,y1,x1-1.0,y1-0.6,x2-1.0,y2-0.6,x2-1.0,y2,-4.0);

    y5=-4.4;
    y6=-4.4-r*sin(-30.0*3.141592/180.0);
    sq_plate2(x1-1.0,y5,x1-1.0,y5-0.6,x2-1.0,y6-0.6,x2-1.0,y6,-4.0);

    x3=4.7;
    x4=4.7+r;
    y3=-4.4;
    y4=-4.4-0.6;
    sq_plate2(x3-1.0,y3,x3-1.0,y4,x4-1.0,y4,x4-1.0,y3,-4.0);


    color_set(0.0,0.0,0.0,0.5);
    sq_plate2(-1*x1+1.0,y1,-1*x1+1.0,y1-0.6,-1*x2+1.0,y2-0.6,-1*x2+1.0,y2,-4.0);
    sq_plate2(-1*x1+1.0,y5,-1*x1+1.0,y5-0.6,-1*x2+1.0,y6-0.6,-1*x2+1.0,y6,-4.0);
    sq_plate2(-1*x3+1.0,y3,-1*x3+1.0,y4,-1*x4+1.0,y4,-1*x4+1.0,y3,-4.0);


  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}



//---------------------------------------------------------------------------
void Toge::TogeObj04_23(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp,int hou){
  //�{�u   (�㉺�ȂǕ����̊� �ڋʐ^�񒆔�)
  //hou�̒l���P�ŏ�A�Q�ŉ�
  double r,r1,r2;
  int i,j;

  //����

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6,-5,-2);
    if(hou==1){  }
    if(hou==2){ glTranslatef(0,6,0); }
    if(hou==3){  }
    if(hou==4){  }

    if((hou==1)||(hou==2)){ glScalef(1.5,3,1); }
    if((hou==3)||(hou==4)){ glScalef(2.5,1.5,1); }
    glRotatef(-80,1,0,0);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6,-5,-2);
    if(hou==1){  }
    if(hou==2){ glTranslatef(0,6,0); }
    if(hou==3){  }
    if(hou==4){  }

    if((hou==1)||(hou==2)){ glScalef(1.5,3,1); }
    if((hou==3)||(hou==4)){ glScalef(2.5,1.5,1); }
    glRotatef(-80,1,0,0);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    if(hou==1){  }
    if(hou==2){ glTranslatef(0,6,0); }
    if(hou==3){  }
    if(hou==4){  }

    if(hou==1){ glTranslatef(6,-9,-4); }
    if(hou==2){ glTranslatef(6,-6,-4); }
    if(hou==3){ glTranslatef(3,-5,-4); }
    if(hou==4){ glTranslatef(9,-5,-4); }
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 1.5, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    if(hou==1){  }
    if(hou==2){ glTranslatef(0,6,0); }
    if(hou==3){  }
    if(hou==4){  }

    if(hou==1){ glTranslatef(-6,-9,-4); }
    if(hou==2){ glTranslatef(-6,-6,-4); }
    if(hou==3){ glTranslatef(-9,-5,-4); }
    if(hou==4){ glTranslatef(-3,-5,-4); }
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 1.5, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    if(hou==1){ glTranslatef(0,-4,0); }
    if(hou==2){ glTranslatef(0,4,0); }
    if(hou==3){  }
    if(hou==4){  }
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    if(hou==1){ glTranslatef(0,-4,0); }
    if(hou==2){ glTranslatef(0,4,0); }
    if(hou==3){  }
    if(hou==4){  }
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    if(hou==1){ glTranslatef(0,-4,-1); }
    if(hou==2){ glTranslatef(0,4,-2); }
    if(hou==3){ glTranslatef(-2,0,0); }
    if(hou==4){ glTranslatef(2,0,0); }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    if(hou==1){ glTranslatef(0,-4,-1); }
    if(hou==2){ glTranslatef(0,3.5,0); }
    if(hou==3){ glTranslatef(-2,0,0); }
    if(hou==4){ glTranslatef(2,0,0); }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    if(hou==1){ glTranslatef(0,-4,0); }
    if(hou==2){ glTranslatef(0,4,0); }
    if(hou==3){  }
    if(hou==4){  }

    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    if(hou==1){ glTranslatef(0,-4,0); }
    if(hou==2){ glTranslatef(0,4,0); }
    if(hou==3){  }
    if(hou==4){  }
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_22(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(�{��H��)
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 3.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 3.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-4);
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.7*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(3.0,-6.3,-4);
    glRotatef(90,0,1,0);
    glRotatef(30,1,0,0);
    GLUquadric* quadricENCHU1=gluNewQuadric();
    gluCylinder(quadricENCHU1, 0.9*db, 0.9*db, 4.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU1);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6+sin(sita*3.14159/180),-5,-4);
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.7*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(-3.0,-6.3,-4);
    glRotatef(-90,0,1,0);
    glRotatef(30,1,0,0);
    GLUquadric* quadricENCHU4=gluNewQuadric();
    gluCylinder(quadricENCHU4, 0.9*db, 0.9*db, 4.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU4);
  glPopMatrix();




  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_21(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u ����[��
  double r,r1,r2,db;
  int i;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(2,2,1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(2,2,1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //���ڂȂ�


  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(-5+3*hi[8],6,-1);
    glRotatef(35,0,0,1);
    glScalef(2,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();

  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(5+3*hi[9],6,-1);
    glRotatef(-35,0,0,1);
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],5,-1);
    glScalef(4,0.7,1);
    GLUquadric* quadricKYU10=gluNewQuadric();
    gluSphere(quadricKYU10, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU10);
  glPopMatrix();

  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],8,-1);
    glScalef(2,0.7,1);
    GLUquadric* quadricKYU11=gluNewQuadric();
    gluSphere(quadricKYU11, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU11);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU13=gluNewQuadric();
    gluSphere(quadricKYU13, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU13);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU14=gluNewQuadric();
    gluSphere(quadricKYU14, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU14);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_20(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u �Â�
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(2,2,1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(2,2,1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(-5+3*hi[8],6,-1);
    glRotatef(45,0,0,1);
    glScalef(2,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();

  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(5+3*hi[9],6,-1);
    glRotatef(-45,0,0,1);
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],4,-1);
    glScalef(4,1,1);
    GLUquadric* quadricKYU10=gluNewQuadric();
    gluSphere(quadricKYU10, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU10);
  glPopMatrix();

  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],8,-1);
    glScalef(2,1,1);
    GLUquadric* quadricKYU11=gluNewQuadric();
    gluSphere(quadricKYU11, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU11);
  glPopMatrix();

  //�̂�
//  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU13=gluNewQuadric();
    gluSphere(quadricKYU13, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU13);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU14=gluNewQuadric();
    gluSphere(quadricKYU14, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU14);
  glPopMatrix();
//  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_19(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u �h��
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  /*
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();
  */

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(4.0,-5.0,-2);
    glRotatef(90,0,1,0);
    GLUquadric* quadricENCHU1=gluNewQuadric();
    gluCylinder(quadricENCHU1, 0.3*db, 0.3*db, 3.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU1);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-4.0,-5.0,-2);
    glRotatef(-90,0,1,0);
    GLUquadric* quadricENCHU4=gluNewQuadric();
    gluCylinder(quadricENCHU4, 0.3*db, 0.3*db, 3.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],6,-1);
    glRotatef(45,0,0,1);
    glScalef(2,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();

  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1);
    glRotatef(-45,0,0,1);
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_18(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp,int rrd){
  //�{�u �ڂ����i�p�x�Frrd�j
  double r,r1,r2,db,gg;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  gg=1.3;

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+gg*sin(rrd*3.14159/180),-5-gg*cos(rrd*3.14159/180),-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6+gg*sin(rrd*3.14159/180),-5-gg*cos(rrd*3.14159/180),-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_17(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u �k����
  double r,r1,r2,db,sp;
  int i,j;

  //���S���W
  if(0==sita % 3){ sp=0.5;}
  if(1==sita % 3){ sp=0.0;}
  if(2==sita % 3){ sp=-0.5;}


  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4]+sp,-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6]+sp,-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180)+sp,-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180)+sp,-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0.0+sp,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0.0+sp,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8]+sp,5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9]+sp,6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5+sp,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5+sp,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_16(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(2,2,1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(2,2,1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(50*sita*3.14159/180),-5,-2);
    glScalef(2,2,1);
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(50*sita*3.14159/180),-5,-2);
    glScalef(2,2,1);
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_15(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  t_amp=shl+1;  //�f�[�^���������l���傫������

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_1_t10(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(TogeObj04_1_t6�̉E�ڏグ)
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-7+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(3.8,-5.3,-2);
    glRotatef(90,0,1,0);
    GLUquadric* quadricENCHU1=gluNewQuadric();
    gluCylinder(quadricENCHU1, 0.3*db, 0.3*db, 3.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU1);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6+sin(sita*3.14159/180),-7,-2);
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(-3.8,-7.3,-2);
    glRotatef(-90,0,1,0);
    GLUquadric* quadricENCHU4=gluNewQuadric();
    gluCylinder(quadricENCHU4, 0.3*db, 0.3*db, 3.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_1_t9(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(\\)
  double r,r1,r2,db;
  //double f1x,f1y,f2x,f2y;

  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(2+hi[0],3+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(2+hi[2],3+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //���� �Ȃ�



  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_1_t8(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(�߂����H)
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(4.5,-6.8,-2);
    glRotatef(90,0,1,0);
    glRotatef(-30,1,0,0);
    GLUquadric* quadricENCHU1=gluNewQuadric();
    gluCylinder(quadricENCHU1, 0.3*db, 0.3*db, 4.0, cutr, 30);
    gluDeleteQuadric(quadricENCHU1);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6+sin(sita*3.14159/180),-5,-2);
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(-4.5,-6.8,-2);
    glRotatef(-90,0,1,0);
    glRotatef(-30,1,0,0);
    GLUquadric* quadricENCHU4=gluNewQuadric();
    gluCylinder(quadricENCHU4, 0.3*db, 0.3*db, 4.0, cutr, 30);
    gluDeleteQuadric(quadricENCHU4);
  glPopMatrix();




  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_1_t7(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(�{��H)
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(3.8,-5.3,-2);
    glRotatef(90,0,1,0);
    glRotatef(30,1,0,0);
    GLUquadric* quadricENCHU1=gluNewQuadric();
    gluCylinder(quadricENCHU1, 0.3*db, 0.3*db, 3.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU1);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6+sin(sita*3.14159/180),-5,-2);
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(-3.8,-5.3,-2);
    glRotatef(-90,0,1,0);
    glRotatef(30,1,0,0);
    GLUquadric* quadricENCHU4=gluNewQuadric();
    gluCylinder(quadricENCHU4, 0.3*db, 0.3*db, 3.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU4);
  glPopMatrix();




  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_1_t6(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(�������H)
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(3.8,-5.3,-2);
    glRotatef(90,0,1,0);
    GLUquadric* quadricENCHU1=gluNewQuadric();
    gluCylinder(quadricENCHU1, 0.3*db, 0.3*db, 3.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU1);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6+sin(sita*3.14159/180),-5,-2);
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();
  glPushMatrix();
    glTranslatef(-3.8,-5.3,-2);
    glRotatef(-90,0,1,0);
    GLUquadric* quadricENCHU4=gluNewQuadric();
    gluCylinder(quadricENCHU4, 0.3*db, 0.3*db, 3.6, cutr, 30);
    gluDeleteQuadric(quadricENCHU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_1_t5(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(�������H)
  double xx1,xx2,yy1,yy2,x1,x2,x3,x4,y1,y2,y3,y4,y5,y6,r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();


    xx1=6+2*hi[4];
    yy1=-5+2*hi[5];
    xx2=-6+2*hi[6];
    yy2=-5+2*hi[7];
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(xx1,yy1,-1.5);
    glRotatef(180,0,1,0);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.6*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(xx2,yy2,-1.5);
    glRotatef(180,0,1,0);
    GLUquadric* quadricHAN2=gluNewQuadric();
    gluDisk(quadricHAN2, 0.0*db, 0.6*db, cutr, 30);
    gluDeleteQuadric(quadricHAN2);
  glPopMatrix();


  //����
  r=2.0;

    color_set(0.0,0.0,0.0,0.5);
    x1=4.7;
    x2=x1+r*cos(30.0*3.141592/180.0);
    y1=-4.4;
    y2=-4.4-r*sin(30.0*3.141592/180.0);
    sq_plate2(x1,y1,x1,y1-0.6,x2,y2-0.6,x2,y2,-2.0);

    y5=-4.4;
    y6=-4.4-r*sin(-30.0*3.141592/180.0);
    sq_plate2(x1,y5,x1,y5-0.6,x2,y6-0.6,x2,y6,-2.0);

    x3=4.7;
    x4=4.7+r;
    y3=-4.4;
    y4=-4.4-0.6;
    sq_plate2(x3,y3,x3,y4,x4,y4,x4,y3,-2.0);


    color_set(0.0,0.0,0.0,0.5);
    sq_plate2(-1*x1,y1,-1*x1,y1-0.6,-1*x2,y2-0.6,-1*x2,y2,-2.0);
    sq_plate2(-1*x1,y5,-1*x1,y5-0.6,-1*x2,y6-0.6,-1*x2,y6,-2.0);
    sq_plate2(-1*x3,y3,-1*x3,y4,-1*x4,y4,-1*x4,y3,-2.0);


  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_1_t4(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u(�Ί�H)
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
    color_set(0.0,0.0,0.0,0.5);

  r=1.2;
  for(i=0;i<30;i++){
  glPushMatrix();
    glTranslatef(5.7+r*cos(i*6*3.141592/180.0),-4.7-r*sin(i*6*3.141592/180.0),-2);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.3*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  }
  for(i=0;i<30;i++){
  glPushMatrix();
    glTranslatef(-5.7+r*cos(i*6*3.141592/180.0),-4.7-r*sin(i*6*3.141592/180.0),-2);
    GLUquadric* quadricHAN1=gluNewQuadric();
    gluDisk(quadricHAN1, 0.0*db, 0.3*db, cutr, 30);
    gluDeleteQuadric(quadricHAN1);
  glPopMatrix();
  }


  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}



//---------------------------------------------------------------------------
void Toge::TogeObj04_14(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u    �������H�i������߂�j
  double r,r1,r2,db;
  int i,j;


  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],4.2,-1.2);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(1.4,0.5,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],7,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(1.0,0.5,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(2+3*hi[8],5.7,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glRotatef(15,0,0,1);
    glScalef(0.5,1.0,1);
    GLUquadric* quadricKYU16=gluNewQuadric();
    gluSphere(quadricKYU16, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU16);
  glPopMatrix();

  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(-2+3*hi[8],5.7,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glRotatef(-15,0,0,1);
    glScalef(0.5,1.0,1);
    GLUquadric* quadricKYU17=gluNewQuadric();
    gluSphere(quadricKYU17, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU17);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU10=gluNewQuadric();
    gluSphere(quadricKYU10, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU10);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_13(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u  �_�O�i���ꗎ����j
  double r,r1,r2,db;
  double g[12],tp;
  int i,j;
  int dsi,gi;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  g[0]=0.01;
  g[1]=0.02;
  g[2]=0.04;
  g[3]=0.08;
  g[4]=0.16;
  g[5]=0.32;
  g[6]=0.64;
  g[7]=1.2;
  g[8]=2.4;
  g[9]=4.8;
  g[10]=9.6;
  g[11]=19.2;
  g[12]=38.4;

  dsi=sita % 120;

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);

    gi=10;
    if(dsi<=gi){ tp=-5+2*hi[5]; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=-5+g[dsi-(gi+1)]+2*hi[5]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(6+2*hi[4],tp,0);

    //glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);

    gi=85;
    if(dsi<=gi){ tp=-5+2*hi[5]; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=-5+g[dsi-(gi+1)]+2*hi[5]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(-6+2*hi[6],tp,0);

    //glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);

    gi=45;
    if(dsi<=gi){ tp=-5; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=-5+g[dsi-(gi+1)]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(6+sin(sita*3.14159/180),tp,-2);

    //glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);

    gi=15;
    if(dsi<=gi){ tp=-5; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=-5+g[dsi-(gi+1)]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(-6-sin(sita*3.14159/180),tp,-2);

    //glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);

    gi=65;
    if(dsi<=gi){ tp=-2; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=-2+g[dsi-(gi+1)]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(0,tp,-2);

    //glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);

    gi=40;
    if(dsi<=gi){ tp=0.8; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=0.8+g[dsi-(gi+1)]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(0,tp,-1.2);

    //glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);

    gi=70;
    if(dsi<=gi){ tp=5; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=5+g[dsi-(gi+1)]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(0+3*hi[8],tp,-1);

    //glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);

    gi=50;
    if(dsi<=gi){ tp=6; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=6+g[dsi-(gi+1)]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(0+3*hi[9],tp,-1.5);

    //glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  //if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);

    gi=30;
    if(dsi<=gi){ tp=6; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=6+g[dsi-(gi+1)]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(0.5,tp,-1.5);

    //glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU10=gluNewQuadric();
    gluSphere(quadricKYU10, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU10);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);

    gi=60;
    if(dsi<=gi){ tp=6; }
    if((dsi>gi)&&(dsi<gi+14)){ tp=6+g[dsi-(gi+1)]; if(tp>11.5){ tp=11.5;}}
    if(dsi>=gi+14){ tp=11.5; }
    glTranslatef(-0.5,tp,-1.5);

    //glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  //}

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_12(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u    �����H�i�����Ђ�ׂ���������j
  double r,r1,r2,db;
  int i,j;


  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,0.5,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,0.5,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU10=gluNewQuadric();
    gluSphere(quadricKYU10, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU10);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_11(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u   �i���ڂƕ@����]�j
  double r,r1,r2,db;
  int i,j,si1,si2,si3;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  r=5.0;
  si1=sita*12;
  si2=sita*12+120;
  si3=sita*12+240;
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glTranslatef(0,r*sin(si1*3.14159/180.0),r-r*cos(si1*3.14159/180.0));
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glTranslatef(0,r*sin(si2*3.14159/180.0),r-r*cos(si2*3.14159/180.0));
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glTranslatef(0,r*sin(si3*3.14159/180.0),r-r*cos(si3*3.14159/180.0));
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glTranslatef(0,r*sin(si3*3.14159/180.0),r-r*cos(si3*3.14159/180.0));
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_10(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u
  //�����Ⴎ����
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_9(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glTranslatef(-3,3,-3);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glTranslatef(3,3,-3);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    glTranslatef(-3,3,-3);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    glTranslatef(3,3,-3);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    glTranslatef(0,-2,-2);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    glTranslatef(0,-2,-2);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(1.5,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glTranslatef(0,-2,-2);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glTranslatef(0,-2,-2);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_8(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u
  double r,r1,r2,db,sz,hy;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  sz=0.0;  //���ڂ̊�{�ʒu����̂���
  hy=0.0;  //�@�i���̃p�[�c�j�̊�{�ʒu����̂���

  switch(t_var){
    case 2:
            db=2.0;
            sz=2.0;
            break;
    case 3:
            db=0.5;
            hy=-0.7;
            break;
    default: break;
  }


  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0+sz);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0+sz);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5+hy,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::TogeObj04_7(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u
  double r,r1,r2;
  int i,j;
  int sita_a;

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

  //�I�v�V����
  sita_a=sita % 60;
  color_set(0.0,0.5,1.0,0.5);

  if((sita_a>0) && (sita_a<20)){ ho(-1*(double)(sita_a/2),3.0,-5); }
  if((sita_a>8) && (sita_a<28)){ nobi(-1*(double)((sita_a-8)/2),3.0,-5); }
  if((sita_a>16) && (sita_a<26)){ mi(-1*(double)((sita_a-16)/2),3.0,-5); }
  if((sita_a>24) && (sita_a<44)){ nobi(-1*(double)((sita_a-24)/2),3.0,-5); }

}


//---------------------------------------------------------------------------
void Toge::TogeObj04_6(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u
  double r,r1,r2,sita2,sita3;
  int i,j;

  sita2=(double)sita;
  sita3=(double)sita;

  switch(t_var){
    case 5:
            sita2=sita2*30.0;
            sita3=sita3*30.0;
            break;
    case 6:
            sita2=sita2*5.0;
            sita3=sita3*1.0;
            break;
    default: break;
  }


  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6,-5,0);
    //glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    //glScalef(1+hi[0],1+hi[1],1);
    glScalef(3,1,1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6,-5,0);
    //glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    //glScalef(1+hi[2],1+hi[3],1);
    glScalef(3,1,1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+2*sin(sita2*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-2*sin(sita2*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita3*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_5_1(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u�i�r�u���[�g��Q�āj
  double r,r1,r2,d1,d2,d3,d4,d5;
  int i,j,sita2;

  sita=(int)sita/2;
  d1=2.0; d2=0.2;  //�ڂ̓���
  d3=1.0; d4=2.0; d5=2.0;  //�A�̓���

  sita2=sita*8;

  switch(t_var){
    case 1:
            sita=sita*2;
            sita2=sita2*2;
            break;
    case 2:
            sita=(int)sita/2;
            sita2=(int)sita2/2;
            break;
    case 3:
            d1=3.0;
            d3=2.0;
            d4=3.0;
            break;
    case 4:
            d1=1.0;
            d3=0.5;
            d4=1.0;
            break;
    default: break;
  }

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6,-5,0);
    //glTranslatef(d1*sin((6+(-5))*30+sita),0,0);
    glScalef(d1+d2*sin(sita2),d1+d2*sin(sita2),1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6,-5,0);
    //glTranslatef(d1*sin((6+(-5))*30+sita),0,0);
    glScalef(d1+d2*sin(sita2),d1+d2*sin(sita2),1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    //glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    glTranslatef(6,-5,-2);
    glTranslatef(d1*sin((6+(-5))*30+sita),0,0);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    //glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    glTranslatef(-6,-5,-2);
    glTranslatef(d1*sin((6+(-5))*30+sita),0,0);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glTranslatef(0,-1,0);
    //glTranslatef(d1*sin((6+(-2))*30+sita),0,0);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glTranslatef(0,-1,0);
    //glTranslatef(d1*sin((6+0.5)*30+sita),0,0);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    //glTranslatef(d1*sin((6+5)*30+sita),0,0);
    //if(t_amp>shl){
      glTranslatef(0,-6,-2);
      glScalef(1.5,1,1);
    //}
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    //glTranslatef(d1*sin((6+6)*30+sita),0,0);
    //if(t_amp>shl){
      glTranslatef(0,3,-2);
      glScalef(1.5,1,1);
    //}
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  //if(t_amp>shl){
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0.5,6,-1.5);
    //glTranslatef(d1*sin((6+6)*30+sita),0,0);
    glTranslatef(1.0,-2,0.5);
    glRotatef(15,0,0,1);
    glRotatef(sita2*d5,1,0,0);
    glScalef(1+d3,2+d4,1);
    GLUquadric* quadricKYU10=gluNewQuadric();
    gluSphere(quadricKYU10, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU10);
  glPopMatrix();
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(-0.5,6,-1.5);
    //glTranslatef(d1*sin((6+6)*30+sita),0,0);
    glTranslatef(-1.0,-2,0.5);
    glRotatef(-15,0,0,1);
    glRotatef(sita2*d5,1,0,0);
    glScalef(1+d3,2+d4,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  //}

}

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void Toge::TogeObj04_5(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u�i�r�u���[�g��P�āF�{�c�ɂȂ����̂Ŏg��Ȃ��j
  double r,r1,r2,d1;
  int i,j;

  sita=(int)sita/2;
  d1=3.0;


  switch(t_var){
    case 1:
            sita=sita*2;
            break;
    case 2:
            sita=(int)sita/2;
            break;
    case 3:
            d1=6.0;
            break;
    case 4:
            d1=1.0;
            break;
    default: break;
  }

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    //glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    //glTranslatef(3*sin((6+(-5+2*hi[5]))*30+sita),0,0);
    //glScalef(1+hi[0],1+hi[1],1);
    glTranslatef(6,-5,0);
    glTranslatef(d1*sin((6+(-5))*30+sita),0,0);
    glScalef(1.5,1.5,1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    //glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    //glScalef(1+hi[2],1+hi[3],1);
    glTranslatef(-6,-5,0);
    glTranslatef(d1*sin((6+(-5))*30+sita),0,0);
    glScalef(1.5,1.5,1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    //glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    glTranslatef(6,-5,-2);
    glTranslatef(d1*sin((6+(-5))*30+sita),0,0);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    //glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    glTranslatef(-6,-5,-2);
    glTranslatef(d1*sin((6+(-5))*30+sita),0,0);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glTranslatef(d1*sin((6+(-2))*30+sita),0,0);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glTranslatef(d1*sin((6+0.5)*30+sita),0,0);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    glTranslatef(d1*sin((6+5)*30+sita),0,0);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    glTranslatef(d1*sin((6+6)*30+sita),0,0);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glTranslatef(d1*sin((6+6)*30+sita),0,0);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glTranslatef(d1*sin((6+6)*30+sita),0,0);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }
}

//---------------------------------------------------------------------------
void Toge::TogeObj04_4(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp,int hou){
  //�{�u   (�㉺�ȂǕ����̊�)
  //hou�̒l���P�ŏ�A�Q�ŉ�
  double r,r1,r2;
  int i,j;

  //����

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6,-5,-2);
    if(hou==1){  }
    if(hou==2){ glTranslatef(0,6,0); }
    if(hou==3){  }
    if(hou==4){  }

    if((hou==1)||(hou==2)){ glScalef(1.5,3,1); }
    if((hou==3)||(hou==4)){ glScalef(2.5,1.5,1); }
    glRotatef(-80,1,0,0);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6,-5,-2);
    if(hou==1){  }
    if(hou==2){ glTranslatef(0,6,0); }
    if(hou==3){  }
    if(hou==4){  }

    if((hou==1)||(hou==2)){ glScalef(1.5,3,1); }
    if((hou==3)||(hou==4)){ glScalef(2.5,1.5,1); }
    glRotatef(-80,1,0,0);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    if(hou==1){  }
    if(hou==2){ glTranslatef(0,6,0); }
    if(hou==3){  }
    if(hou==4){  }

    if(hou==1){ glTranslatef(6,-9,-4); }
    if(hou==2){ glTranslatef(6,-1,-4); }
    if(hou==3){ glTranslatef(3,-5,-4); }
    if(hou==4){ glTranslatef(9,-5,-4); }
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    if(hou==1){  }
    if(hou==2){ glTranslatef(0,6,0); }
    if(hou==3){  }
    if(hou==4){  }

    if(hou==1){ glTranslatef(-6,-9,-4); }
    if(hou==2){ glTranslatef(-6,-1,-4); }
    if(hou==3){ glTranslatef(-9,-5,-4); }
    if(hou==4){ glTranslatef(-3,-5,-4); }
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    if(hou==1){ glTranslatef(0,-4,0); }
    if(hou==2){ glTranslatef(0,4,0); }
    if(hou==3){  }
    if(hou==4){  }
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    if(hou==1){ glTranslatef(0,-4,0); }
    if(hou==2){ glTranslatef(0,4,0); }
    if(hou==3){  }
    if(hou==4){  }
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    if(hou==1){ glTranslatef(0,-4,-1); }
    if(hou==2){ glTranslatef(0,4,-2); }
    if(hou==3){ glTranslatef(-2,0,0); }
    if(hou==4){ glTranslatef(2,0,0); }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    if(hou==1){ glTranslatef(0,-4,-1); }
    if(hou==2){ glTranslatef(0,3.5,0); }
    if(hou==3){ glTranslatef(-2,0,0); }
    if(hou==4){ glTranslatef(2,0,0); }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    if(hou==1){ glTranslatef(0,-4,0); }
    if(hou==2){ glTranslatef(0,4,0); }
    if(hou==3){  }
    if(hou==4){  }

    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    if(hou==1){ glTranslatef(0,-4,0); }
    if(hou==2){ glTranslatef(0,4,0); }
    if(hou==3){  }
    if(hou==4){  }
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}



//---------------------------------------------------------------------------
void Toge::TogeObj04_3(double ir,double ig,double ib,double ia)
{
   int i;

   for(i=0;i<100;i++){
    color_set(ir,ig,ib,ia);
    glBegin(GL_POLYGON);
      glNormal3f(0.0f,0.0f,-1.0f);
      glVertex3d(10-i*0.2,-10,-10);
      glVertex3d(10-i*0.2,10,-10);
      glVertex3d(9.9-i*0.2,10,-10);
      glVertex3d(9.9-i*0.2,-10,-10);
    glEnd();

    color_set(0.0,0.0,0.0,ia);
    glBegin(GL_POLYGON);
      glNormal3f(0.0f,0.0f,-1.0f);
      glVertex3d(9.9-i*0.2,-10,-10);
      glVertex3d(9.9-i*0.2,10,-10);
      glVertex3d(9.8-i*0.2,10,-10);
      glVertex3d(9.8-i*0.2,-10,-10);
    glEnd();
   }

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_2(double ir,double ig,double ib,double ia)
{
    color_set(ir,ig,ib,ia);
    glBegin(GL_POLYGON);
      glNormal3f(0.0f,0.0f,-1.0f);
      glVertex3d(10,-10,-10);
      glVertex3d(10,10,-10);
      glVertex3d(-10,10,-10);
      glVertex3d(-10,-10,-10);
    glEnd();

}
//---------------------------------------------------------------------------
void Toge::TogeObj04_1(int sita,int n,double hi[],int cutr,int shl,int t_var,int t_amp){
  //�{�u
  double r,r1,r2,db;
  int i,j;

  db=1.0;  //���ꂼ��̃p�[�c�̔{��

  //����
  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(6+2*hi[4],-5+2*hi[5],0);
    glScalef(1+hi[0],1+hi[1],1);
    GLUquadric* quadricKYU1=gluNewQuadric();
    gluSphere(quadricKYU1, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU1);
  glPopMatrix();

  glPushMatrix();
    color_set(1.0,1.0,1.0,0.5);
    glTranslatef(-6+2*hi[6],-5+2*hi[7],0);
    glScalef(1+hi[2],1+hi[3],1);
    GLUquadric* quadricKYU2=gluNewQuadric();
    gluSphere(quadricKYU2, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU2);
  glPopMatrix();

  //����
  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(6+sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU3=gluNewQuadric();
    gluSphere(quadricKYU3, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU3);
  glPopMatrix();

  glPushMatrix();
    color_set(0.0,0.0,0.0,0.5);
    glTranslatef(-6-sin(sita*3.14159/180),-5,-2);
    if(t_amp>shl){  glScalef(2,2,1); }
    else{ glScalef(1,1,1); }
    GLUquadric* quadricKYU4=gluNewQuadric();
    gluSphere(quadricKYU4, 0.5*db, cutr, 30);
    gluDeleteQuadric(quadricKYU4);
  glPopMatrix();

  //�@
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,-2,-2);
    glScalef(1,2,1);
    GLUquadric* quadricKYU5=gluNewQuadric();
    gluSphere(quadricKYU5, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU5);
  glPopMatrix();
  glPushMatrix();
    color_set(1.0,0.5,0.0,0.5);
    glTranslatef(0,0.5,-1.2);
    glScalef(1.5+0.5*sin(sita*3.14159/180),0.8,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();

  //��
  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[8],5,-1);
    if(t_amp>shl){
      glTranslatef(0,-4,-2);
      glScalef(1.5,1,1);
    }
    glScalef(3,1,1);
    GLUquadric* quadricKYU6=gluNewQuadric();
    gluSphere(quadricKYU6, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU6);
  glPopMatrix();


  glPushMatrix();
    color_set(0.8,0.0,0.0,0.5);
    glTranslatef(0+3*hi[9],6,-1.5);
    if(t_amp>shl){
      glTranslatef(0,2,-2);
      glScalef(1.5,1,1);
    }
    glScalef(2,1,1);
    GLUquadric* quadricKYU7=gluNewQuadric();
    gluSphere(quadricKYU7, 2.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU7);
  glPopMatrix();

  //�̂�
  if(t_amp>shl){
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(0.5,6,-1.5);
    glRotatef(15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU8=gluNewQuadric();
    gluSphere(quadricKYU8, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU8);
  glPopMatrix();
  glPushMatrix();
    color_set(0.6,0.0,0.1,0.5);
    glTranslatef(-0.5,6,-1.5);
    glRotatef(-15,0,0,1);
    glScalef(1,2,1);
    GLUquadric* quadricKYU9=gluNewQuadric();
    gluSphere(quadricKYU9, 1.0*db, cutr, 30);
    gluDeleteQuadric(quadricKYU9);
  glPopMatrix();
  }

}

//---------------------------------------------------------------------------
void Toge::Kyu(double r,double xy,double yz){
//���������֐�
glBegin(GL_POLYGON);
  GLUquadric* quadric=gluNewQuadric();
  gluSphere(quadric, r, 30, 30);
  gluDeleteQuadric(quadric);
glEnd();
}

//---------------------------------------------------------------------------
void Toge::Ensui(double r1,double r2,double h){
//�~���������֐�
glBegin(GL_POLYGON);
  GLUquadric* quadric=gluNewQuadric();
  gluCylinder(quadric, r1,r2,h, 30, 30);
  gluDeleteQuadric(quadric);
glEnd();
}

//---------------------------------------------------------------------------
void Toge::Box(double x0,double x1,double y0,double y1,double z0,double z1)
{
//����`���֐�
glBegin(GL_POLYGON);
    glNormal3f(0.0f,0.0f,1.0f);
    glVertex3d(x0,y1,z1);
    glVertex3d(x0,y0,z1);
    glVertex3d(x1,y0,z1);
    glVertex3d(x1,y1,z1);
glEnd();
glBegin(GL_POLYGON);
    glNormal3f(1.0f,0.0f,0.0f);
    glVertex3d(x1,y1,z1);
    glVertex3d(x1,y0,z1);
    glVertex3d(x1,y0,z0);
    glVertex3d(x1,y1,z0);
glEnd();
glBegin(GL_POLYGON);
    glNormal3f(0.0f,0.0f,-1.0f);
    glVertex3d(x1,y1,z0);
    glVertex3d(x1,y0,z0);
    glVertex3d(x0,y0,z0);
    glVertex3d(x0,y1,z0);
glEnd();
glBegin(GL_POLYGON);
    glNormal3f(-1.0f,0.0f,0.0f);
    glVertex3d(x0,y1,z0);
    glVertex3d(x0,y0,z0);
    glVertex3d(x0,y0,z1);
    glVertex3d(x0,y1,z1);
glEnd();
glBegin(GL_POLYGON);
    glNormal3f(0.0f,-1.0f,0.0f);
    glVertex3d(x0,y0,z1);
    glVertex3d(x0,y0,z0);
    glVertex3d(x1,y0,z0);
    glVertex3d(x1,y0,z1);
glEnd();
glBegin(GL_POLYGON);
    glNormal3f(0.0f,1.0f,0.0f);
    glVertex3d(x0,y1,z0);
    glVertex3d(x0,y1,z1);
    glVertex3d(x1,y1,z1);
    glVertex3d(x1,y1,z0);
glEnd();
}


//---------------------------------------------------------------------------
void Toge::tri_plate(double x1,double y1,double x2,double y2,double x3,double y3,double z){
  //z���ɐ����ȎO�p�`�̔�\������
  //���W�͎��v����1,2,3�̏��œ����
glBegin(GL_POLYGON);
    glNormal3f(0.0f,0.0f,-1.0f);
    glVertex3d(x1,y1,z);
    glVertex3d(x2,y2,z);
    glVertex3d(x3,y3,z);
glEnd();
}
//---------------------------------------------------------------------------
void Toge::tri_plate2(double xa,double ya,double e1,double e2,double alh,double z){
  //z���ɐ����ȎO�p�`�̖���\������
  //xa,ya�͖��̈ʒu�Ae1�͖��̒����Ae2�͖��̕��Aalh�͖��̊p�x�Bz��Z����̈ʒu

  double xb,yb,xc,yc,xd,yd;

  xb=xa+e1*cos(alh*3.141592/180);
  yb=ya+e1*sin(alh*3.141592/180);
  xc=xa+e2*cos((alh+90)*3.141592/180);
  yc=ya+e2*sin((alh+90)*3.141592/180);
  xd=xa+e2*cos((alh-90)*3.141592/180);
  yd=ya+e2*sin((alh-90)*3.141592/180);

  //sq_plate(xb,xb+0.5,-1*yb,-1*yb+0.5,-5.1);
  tri_plate(xb,-1*yb,xd,-1*yd,xc,-1*yc,z);
}
//---------------------------------------------------------------------------
void Toge::sq_plate2(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4,double z){
  //z���ɐ����Ȏl�p�`�̔�\������
  //���W�͎��v����1,2,3,4�̏��œ����
glBegin(GL_POLYGON);
    glNormal3f(0.0f,0.0f,-1.0f);
    glVertex3d(x1,y1,z);
    glVertex3d(x2,y2,z);
    glVertex3d(x3,y3,z);
    glVertex3d(x4,y4,z);
glEnd();
}
//---------------------------------------------------------------------------
void Toge::sq_plate(double x1,double x2,double y1,double y2,double z){
  //z���ɐ����Ȑ����`�A�����`�̔�\������
glBegin(GL_POLYGON);
    glNormal3f(0.0f,0.0f,-1.0f);
    glVertex3d(x2,y1,z);
    glVertex3d(x2,y2,z);
    glVertex3d(x1,y2,z);
    glVertex3d(x1,y1,z);
glEnd();
}
//---------------------------------------------------------------------------
void Toge::penta_plate(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4,double x5,double y5,double z){
  //z���ɐ����Ȍ܊p�`�̔�\������
  //���W�͎��v����1,2,3,4,5�̏��œ����
glBegin(GL_POLYGON);
    glNormal3f(0.0f,0.0f,-1.0f);
    glVertex3d(x1,y1,z);
    glVertex3d(x2,y2,z);
    glVertex3d(x3,y3,z);
    glVertex3d(x4,y4,z);
    glVertex3d(x5,y5,z);
glEnd();
}

//---------------------------------------------------------------------------
void Toge::drop_plate(double xa,double ya,double e1,double e2,double alh,double z){
  //z���ɐ����Ȑ��H�^�̃v���[�g��\������
  //xa,ya�͐��H�̈ʒu�Ae1�͐��H�̐K���̒����Ae2�͐��H�̔��a�Aalh�͐��H�̊p�x�Bz��Z����̈ʒu

  tri_plate2(xa,ya,e1,e2,alh,z);

  glPushMatrix();
    glTranslatef(xa,-1*ya,z);
    glRotatef(180,1,0,0);
    GLUquadric* quadricHAN=gluNewQuadric();
    gluDisk(quadricHAN, 0.0, e2, 30, 30);
    gluDeleteQuadric(quadricHAN);
  glPopMatrix();

}
//---------------------------------------------------------------------------
void Toge::ho(double x0,double y0,double z0){
  double haba,hi;

  haba=0.5;
  hi=3.0;
  Box(x0-haba,x0+haba,y0-hi,y0+hi,z0-haba,z0+haba);
  Box(x0-hi,x0+hi,y0-hi/2-haba,y0-hi/2+haba,z0-haba,z0+haba);

  glPushMatrix();
    glRotatef(-15,0,0,1);
    Box(x0+hi/2-haba,x0+hi/2+haba,y0,y0+hi,z0-haba,z0+haba);
  glPopMatrix();

  glPushMatrix();
    glRotatef(15,0,0,1);
    Box(x0-hi/2-haba,x0-hi/2+haba,y0,y0+hi,z0-haba,z0+haba);
  glPopMatrix();


}

//---------------------------------------------------------------------------
void Toge::nobi(double x0,double y0,double z0){
  double haba,hi;

  haba=0.5;
  hi=3.0;
  Box(x0-hi,x0+hi,y0-haba,y0+haba,z0-haba,z0+haba);

}

//---------------------------------------------------------------------------
void Toge::mi(double x0,double y0,double z0){
  double haba,hi;

  haba=0.5;
  hi=3.0;

  glPushMatrix();
    glRotatef(15,0,0,1);
    Box(x0-hi/2,x0+hi/2,y0-haba,y0+haba,z0-haba,z0+haba);
  glPopMatrix();
  glPushMatrix();
    glRotatef(15,0,0,1);
    Box(x0-hi/2,x0+hi/2,y0-hi/1.5-haba,y0-hi/1.5+haba,z0-haba,z0+haba);
  glPopMatrix();
  glPushMatrix();
    glRotatef(15,0,0,1);
    Box(x0-hi/2,x0+hi/2,y0+hi/1.5-haba,y0+hi/1.5+haba,z0-haba,z0+haba);
  glPopMatrix();


}

//---------------------------------------------------------------------------
void Toge::Frame(double x0,double x1,double y0,double y1,double z0,double z1)
{
//�g�`��
//GLfloat materialWhite[]={1.0f,1.0f,1.0f,1.0f};
GLfloat materialGray[]={0.9f,0.9f,0.9f,0.5f};
glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,materialGray);
glLineWidth(4.0f);
glBegin(GL_LINE_LOOP);
    glVertex3d(x1,y1,z0);
    glVertex3d(x1,y0,z0);
    glVertex3d(x0,y0,z0);
    glVertex3d(x0,y1,z0);
glEnd();
glBegin(GL_LINES);
    glVertex3d(x1,y0,z1);
    glVertex3d(x1,y0,z0);
glEnd();
glBegin(GL_LINES);
    glVertex3d(x0,y0,z0);
    glVertex3d(x0,y0,z1);
glEnd();
glBegin(GL_LINES);
    glVertex3d(x1,y1,z0);
    glVertex3d(x1,y1,z1);
glEnd();
glBegin(GL_LINES);
    glVertex3d(x0,y1,z0);
    glVertex3d(x0,y1,z1);
glEnd();
}
//---------------------------------------------------------------------------
void Toge::color_set(double r,double g,double b,double alpha)
{
  GLfloat r_e,g_e,b_e,alpha_e;
  r_e=r;
  g_e=g;
  b_e=b;
  alpha_e=alpha;

  GLfloat ambient1  [] = {0.1f, 0.1f, 0.1f, 1.0f};
  GLfloat diffuse1  []={r_e,g_e,b_e,alpha_e};
  GLfloat specular1 [] = {1.0f, 1.0f, 1.0f, 1.0f};
  GLfloat shininess1[] = {0.0f};
  glMaterialfv(GL_FRONT, GL_AMBIENT, ambient1);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse1);
  glMaterialfv(GL_FRONT, GL_SPECULAR, specular1);
  glMaterialfv(GL_FRONT, GL_SHININESS, shininess1);

}
