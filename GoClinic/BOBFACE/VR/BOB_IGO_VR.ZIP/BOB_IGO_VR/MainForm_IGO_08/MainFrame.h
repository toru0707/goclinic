//---------------------------------------------------------------------------

#ifndef MainFrameH
#define MainFrameH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

#include "Toge.cpp"
#include "visualizer.h"
#include <ComCtrls.hpp> //�r�W���A���C�U�i�����j
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE �Ǘ��̃R���|�[�l���g
        TPanel *Panel01;
        TSplitter *Splitter1;
        TPanel *Panel02;
        TPanel *Panel1;
        TSplitter *Splitter2;
        TPanel *Panel2;
        TPanel *Panel3;
        TSplitter *Splitter3;
        TPanel *Panel4;
        TFrame_V *Frame_V;
        TCheckBox *CheckBox1;
        TEdit *Edit1;
        TUpDown *UpDown1;
        TButton *Button1;
        TMemo *Memo1;
        TEdit *Edit2;
        TEdit *Edit3;
        TUpDown *UpDown2;
        TUpDown *UpDown3;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *Edit4;
        TLabel *Label5;
        TLabel *Label6;
        TUpDown *UpDown4;
        TEdit *Edit5;
        TLabel *Label7;
        TEdit *Edit6;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        void __fastcall Frame_V1Button_V01Click(TObject *Sender);
        void __fastcall Frame_V1Timer_VTimer(TObject *Sender);
        void __fastcall Frame_VButton_V02Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
private:	// ���[�U�[�錾
public:		// ���[�U�[�錾

  //�r�W���A���C�U�Ŏg�p����ϐ��̐錾�i_V�j
  HDC dcx_V;     //�r�W���A���C�U�̏o�͐�R���|�[�l���g�̃n���h��
  Toge *obj_V;   //Toge�N���X�ϐ�
  int cou_V;     //�e�X�g�p


        __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
